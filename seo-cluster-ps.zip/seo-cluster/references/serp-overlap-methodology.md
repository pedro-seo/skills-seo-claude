# Metodología de Solapamiento de SERP

## Principio Fundamental

Dos keywords que devuelven los mismos resultados de Google deberían apuntar a la misma página.
Dos keywords que devuelven resultados completamente distintos necesitan páginas separadas. Este es
el fundamento del clustering basado en SERP -- usar las propias decisiones de ranking de Google para
determinar la arquitectura de contenido, en lugar de basarse en la similitud de texto o el stemming de las keywords.

## Algoritmo de Puntuación

### Paso 1: Recolectar Datos de SERP

Para cada keyword del conjunto candidato, obtén los 10 primeros resultados orgánicos:
- Usa WebSearch o `serp_organic_live_advanced` de DataForSEO
- Extrae únicamente las URLs de resultados orgánicos (ignora anuncios, featured snippets, PAA, knowledge panels)
- Normaliza las URLs: elimina el protocolo, la barra final y los parámetros de consulta (excepto los relevantes)
- Guarda como un conjunto de 10 URLs por keyword

### Paso 2: Comparación por Pares

Para cada par de keywords (A, B):
1. Obtén los conjuntos de URLs: `urls_A` y `urls_B`
2. Calcula el solapamiento: `shared = urls_A intersección urls_B`
3. Puntuación: `overlap_score = len(shared)`

### Paso 3: Aplicar Umbrales

| Puntuación de Solapamiento | Relación | Acción |
|------------------------------|----------|--------|
| 7-10 | **Mismo post** | Fusiona las keywords en una única página objetivo. Usa la keyword de mayor volumen como principal. |
| 4-6 | **Mismo cluster** | Colócalas en el mismo spoke cluster. Pueden ser posts separados o el mismo post según la diferencia de volumen. |
| 2-3 | **Enlazar entre sí** | Colócalas en clusters adyacentes. Crea enlaces internos entre clusters. |
| 0-1 | **Separado** | Clusters completamente distintos o excluir del tema pilar actual. |

### Paso 4: Gestionar Puntuaciones Ambiguas (Rango 3-4)

Las puntuaciones en el rango 3-4 requieren un desempate:
1. Comprueba el solapamiento de dominios (mismos dominios pero páginas distintas = relación más cercana)
2. Comprueba la alineación de intención (misma categoría de intención = tiende al mismo cluster)
3. Comprueba el ratio de volumen (si una keyword tiene 10 veces o más volumen, probablemente merezca su propio post)
4. En caso de duda, mantenlas en el mismo cluster con posts separados (prioriza la cohesión)

## Estrategia de Optimización

La comparación completa por pares de N keywords requiere N*(N-1)/2 consultas de SERP. Para 40
keywords, son 780 comparaciones. Optimiza reduciendo comprobaciones innecesarias:

### Preagrupación

1. Clasifica todas las keywords por intención (Informacional, Comercial, Transaccional)
2. Agrupa las keywords que comparten el mismo término principal (p. ej., variantes de "software CRM")
3. Ejecuta la comparación de SERP por pares solo dentro de cada pregrupo
4. Verifica de forma cruzada las keywords límite (mayor volumen de cada grupo) entre grupos

### Reglas de Omisión

- Si las keywords A y B son ambas variantes long-tail del mismo término principal Y comparten
  la misma intención, asume un solapamiento de 4-6 (mismo cluster) sin comprobar el SERP
- Si las keywords están en categorías de intención distintas, asume un solapamiento de 0-2 salvo que
  compartan término principal
- Verifica las suposiciones con comprobaciones puntuales de SERP (muestra el 20% de los pares omitidos)

## Formato de la Matriz de Puntuación

Guarda los datos de solapamiento como una matriz simétrica en `cluster-plan.json`:

```json
{
  "serp_matrix": {
    "keywords": ["keyword-a", "keyword-b", "keyword-c"],
    "scores": [
      [10, 5, 1],
      [5, 10, 3],
      [1, 3, 10]
    ]
  }
}
```

La diagonal siempre es 10 (una keyword se solapa perfectamente consigo misma).

## Antipatrones

1. **Nunca agrupes solo por similitud de texto.** "Consejos de adiestramiento canino" y "clases de
   adiestramiento canino" pueden tener SERPs completamente distintos pese al texto similar.
2. **Nunca uses agrupación solo por stemming.** "Correr" y "corriendo" pueden apuntar a
   intenciones completamente distintas.
3. **Nunca asumas que las búsquedas relacionadas pertenecen al mismo cluster.** Verifícalo con datos de SERP.
4. **Nunca ignores las diferencias en las funciones del SERP.** Si la keyword A activa un pack local y
   la keyword B activa un featured snippet, probablemente necesiten tipos de contenido distintos
   aunque haya un solapamiento moderado de URLs.
5. **Nunca trates todos los dominios por igual.** Wikipedia y Reddit aparecen en muchos SERPs.
   Considera filtrar los dominios más ubicuos (top 5 más comunes) antes de puntuar, o
   ponderar más los resultados específicos de dominio.

## Prioridad de Fuentes de Datos

1. **DataForSEO** (si está disponible): datos de SERP más fiables y consistentes. Usa
   `serp_organic_live_advanced` con `location_code: 2840` (EE.UU.) y `language_code: "es"` según el mercado objetivo.
2. **WebSearch** (alternativa): adecuado para el clustering, aunque los resultados pueden variar según la sesión.
   Ejecuta varias búsquedas para la misma keyword y usa el conjunto de resultados más común.

## Caché

Dentro de una misma sesión de clustering, guarda en caché todos los resultados de SERP. Si los resultados
de la keyword A se obtuvieron para la comparación A-B, reutilízalos para la comparación A-C. Esto reduce
a la mitad el número real de consultas de SERP necesarias.
