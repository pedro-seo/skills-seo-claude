# Referencia de Costes de la API de DataForSEO

## Niveles de Precios (USD por llamada, cola estándar)

| Categoría | Endpoint | Coste/Llamada | Notas |
|-----------|----------|-------------------|-------|
| **SERP** | `serp_*_live_advanced` | 0,002$ | Por cada 100 resultados |
| **SERP** | `serp_*_live_regular` | 0,001$ | Ligero |
| **SERP Imágenes** | `serp_google_images_live_*` | 0,002$ | 5x con operadores site:/filetype: |
| **Keywords** | `kw_data_google_ads_search_volume` | 0,05$ | Por lote de keywords |
| **Keywords** | `kw_data_google_trends_explore` | 0,01$ | Por consulta |
| **Labs** | `dataforseo_labs_*_keyword_*` | 0,05$ | Ideas, sugerencias, relacionadas |
| **Labs** | `dataforseo_labs_bulk_*` | 0,01$ | Dificultad, tráfico |
| **Labs** | `dataforseo_labs_*_domain_*` | 0,05$ | Competidores, intersección |
| **On-Page** | `on_page_instant_pages` | 0,01$ | Análisis rápido |
| **On-Page** | `on_page_lighthouse` | 0,02$ | Lighthouse completo |
| **Backlinks** | `backlinks_*` | 0,02$ | Por subllamada |
| **Contenido** | `content_analysis_*` | 0,02$ | Búsqueda, resumen, tendencias |
| **Negocio** | `business_data_*` | 0,05$ | Búsqueda de fichas |
| **IA/GEO** | `ai_optimization_*` | 0,05$ | Scraper de ChatGPT, menciones LLM |
| **Merchant** | `merchant_*` | 0,02$ | Google Shopping, Amazon |
| **Dominio** | `domain_analytics_whois_*` | 0,005$ | Datos WHOIS |
| **Dominio** | `domain_analytics_technologies_*` | 0,01$ | Stack tecnológico |

## Presets de Presupuesto

| Preset | Límite Diario | Umbral | Modo | Ideal Para |
|--------|-------------------|--------|------|------------|
| **Conservador** | 2,00$ | 0,10$ | threshold | Aprendizaje, pruebas |
| **Estándar** | 10,00$ | 0,50$ | threshold | Auditorías habituales |
| **Agresivo** | 50,00$ | 2,00$ | threshold | Trabajo masivo de agencia |
| **Ilimitado** | 999,00$ | -- | none | Flujos de confianza |

Configura con: `python3 scripts/dataforseo_costs.py config --mode threshold --threshold 0.50 --daily-limit 10.00`

## Consejos para Reducir Costes

- Usa `live_regular` en lugar de `live_advanced` cuando no necesites todas las funciones de SERP (ahorro del 50%)
- Agrupa keywords en una sola llamada a `search_volume` en lugar de búsquedas individuales de SERP
- Usa la cola `standard` en lugar de `live` para análisis no urgentes (ahorro del 60-80%)
- Evita los operadores `site:` y `filetype:` en las consultas de SERP de imágenes (multiplicador de coste x5)
- Cachea los resultados de la sesión — no vuelvas a pedir la misma keyword/dominio dentro de una sesión

## Flujo de Aprobación

Antes de cualquier llamada a la API MCP de DataForSEO:
1. Ejecuta `python3 scripts/dataforseo_costs.py check <endpoint> [--count N]`
2. Si `status: "approved"` → continúa
3. Si `status: "needs_approval"` → muestra el coste al usuario, pide confirmación
4. Si `status: "blocked"` → informa al usuario de que se superaría el límite diario
5. Tras completar la llamada, registra: `python3 scripts/dataforseo_costs.py log <endpoint> <coste>`

## Endpoints con Aviso

Estos endpoints siempre requieren confirmación del usuario independientemente del modo de aprobación:
- `backlinks_backlinks` (puede generar conjuntos de resultados grandes)
- `backlinks_domain_intersection` (comparación multi-dominio costosa)
- `ai_optimization_chat_gpt_scraper` (scraping web de ChatGPT)
- `ai_opt_llm_ment_search` (seguimiento de menciones LLM)
- `merchant_amazon_products_search` (datos de productos de Amazon)
