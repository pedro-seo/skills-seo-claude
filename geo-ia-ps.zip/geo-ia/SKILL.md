---
name: geo-ia
description: >
  GEO (Generative Engine Optimization): optimiza webs para ser citadas por ChatGPT, Claude,
  Perplexity, Gemini y Google AI Overviews. Audita citabilidad, analiza rastreadores de IA,
  genera llms.txt, detecta menciones de marca en respuestas IA y optimiza contenido para
  aparecer en respuestas generativas. Úsala cuando el usuario diga "GEO", "IA Overviews",
  "AI search", "ChatGPT me cita", "aparecer en Perplexity", "visibilidad en IA",
  "llms.txt", "citabilidad IA", "optimización para IA" o "generative engine optimization".
user-invocable: true
argument-hint: "<url>"
---

# GEO — Generative Engine Optimization — Palo Seco

Optimización para motores de búsqueda generativos. El SEO del presente y del futuro inmediato.

## Contexto

Los LLMs (ChatGPT, Claude, Perplexity, Gemini) están reemplazando parcialmente las búsquedas tradicionales. Una web puede tener buen ranking en Google y ser invisible para la IA — y viceversa. GEO es la disciplina que cierra esa brecha.

## Áreas de análisis GEO

### 1. Rastreabilidad por crawlers de IA
- `robots.txt`: ¿permite GPTBot, ClaudeBot, PerplexityBot, Google-Extended?
- `llms.txt`: ¿existe? ¿está bien estructurado?
- Sitemap accesible para bots de IA
- Tiempo de respuesta del servidor ante crawlers

### 2. Citabilidad del contenido
Factores que aumentan la probabilidad de ser citado:
- **Definiciones claras** — el contenido define conceptos de forma precisa y concisa
- **Datos y estadísticas propios** — cifras originales que otros citan
- **Estructura escaneable** — H2s descriptivos, listas, tablas
- **Autoría visible** — autor identificado con credenciales reales
- **Fecha de actualización** — contenido fresco con fecha visible
- **Fuentes referenciadas** — el contenido cita fuentes de autoridad

### 3. E-E-A-T para IA
- Experiencia demostrada: casos reales, ejemplos propios, metodología propia
- Expertise: credenciales del autor visibles en la página
- Autoridad: menciones externas de la marca/autor
- Confianza: política de privacidad, contacto, sobre nosotros completos

### 4. Menciones de marca en respuestas IA
- Comprobar si ChatGPT/Perplexity/Claude mencionan la marca al responder sobre el sector
- Identificar temas donde la marca debería aparecer y no aparece
- Analizar competidores que sí aparecen y por qué

### 5. Schema para IA
- Article, FAQPage, HowTo — los más citados por modelos generativos
- speakable — para respuestas de voz y IA conversacional
- Organization con sameAs completo

### 6. Generación de llms.txt
Genera el archivo `llms.txt` optimizado con:
- Descripción de la empresa y propuesta de valor
- Productos/servicios principales
- URLs clave que los LLMs deben conocer
- Formato compatible con el estándar llms.txt

## Output GEO

- **GEO Score** (0-100): citabilidad estimada actual
- Hallazgos por área con impacto estimado
- `llms.txt` generado y listo para implementar
- Plan de acción priorizado para aumentar visibilidad en IA
- Comparativa con 2-3 competidores si se conocen

## Nota Palo Seco

GEO no reemplaza SEO — lo complementa. Una web con buen SEO técnico ya tiene la mitad del trabajo GEO hecho. El resto es estructura de contenido, autoría y datos propios.
