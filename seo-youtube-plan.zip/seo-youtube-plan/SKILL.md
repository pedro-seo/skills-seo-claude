---
name: seo-youtube-plan
description: >
  Genera un plan estratégico de contenido de YouTube cruzando Google Search
  Console (páginas del blog en posición de mejora), la SERP real de YouTube
  (DataForSEO) y datos de volumen/keywords de Semrush MCP. Clasifica cada
  oportunidad en tres buckets: reforzar contenido casi-top con vídeo
  embebido (SEO 2x1), reforzar+mejorar contenido en posiciones intermedias,
  o crear pieza nueva desde cero. Produce un Excel de plan de contenidos con
  estados de producción y un resumen ejecutivo en PowerPoint para presentar
  al cliente. Úsala cuando el usuario diga "plan de contenidos YouTube",
  "estrategia SEO YouTube", "plan de vídeos", "SEO 2x1", "qué vídeos
  grabar" o "roadmap de YouTube para cliente".
user-invocable: true
argument-hint: "<dominio o cliente>"
license: MIT
compatibility: "Requiere acceso a Google Search Console del cliente. Mejorada con Semrush MCP y DataForSEO MCP (ambas opcionales pero muy recomendadas)"
metadata:
  author: Palo Seco S.L.
  version: "1.2.0"
  category: seo
---

# Planificador Estratégico de SEO YouTube + Blog (SEO 2x1)

Cruza el rendimiento real del blog en Google con la demanda real de vídeo en
YouTube para decidir, con datos y no con intuición, qué vídeos grabar y en
qué artículos embeberlos. El objetivo final no es "hacer vídeos" — es sumar
señales a contenido que YA casi rankea, y solo crear piezas nuevas desde
cero cuando hay demanda de vídeo validada y ningún activo que reforzar.

## Filosofía del Método

1. **GSC no mide YouTube.** Sirve para encontrar qué páginas del blog están
   "a un empujón" de subir posiciones (zona de impacto / *striking
   distance*), no para saber qué se busca en YouTube.
2. **DataForSEO SERP de YouTube es quien valida la intención de vídeo.**
   Semrush da volumen e ideación (de Google, no de YouTube — es una señal
   proxy). DataForSEO confirma si YouTube trata esa keyword como consulta de
   vídeo y quién ya rankea ahí.
3. **No todo el contenido en zona de impacto se beneficia igual de un
   vídeo.** Solo lo hacen las intenciones informacionales, comparativas,
   tutoriales o de "cómo hacer". Una query transaccional corta no gana nada
   con un embed.
4. **El "2x1" es real cuando hay dos caminos de tráfico**: el vídeo aporta
   señales de refuerzo a la página (dwell time, posible carrusel de vídeo en
   el SERP si hay schema `VideoObject`), y además genera tráfico propio
   desde la búsqueda de YouTube.

---

## Proceso

### Paso 1 — Extracción de Google Search Console

Los datos SIEMPRE salen de Google Search Console del cliente. Dos formas de
entrada válidas:

**A) Export de GSC subido por el usuario (lo más habitual).** Es un `.xlsx`
con estas hojas: `Consultas`, `Páginas`, `Países`, `Dispositivos`,
`Aparición en búsquedas`, `Filtros`. Léelo con la skill `xlsx` / `openpyxl`.
De cada hoja obtienes:
- Hoja **`Páginas`** → columnas `Páginas principales` (la **URL real y
  literal**), `Clics`, `Impresiones`, `CTR`, `Posición`. Esta es tu fuente de
  URLs. **Copia la URL tal cual aparece; nunca la reconstruyas ni la inventes.**
- Hoja **`Consultas`** → `Consultas principales`, `Clics`, `Impresiones`,
  `CTR`, `Posición`. Sirve para detectar keywords informacionales con demanda
  que NO tienen un artículo propio que las trabaje (candidatas a `Crear nuevo`).

> Nota importante: el export estándar de GSC trae `Consultas` y `Páginas` en
> hojas SEPARADAS, sin el mapa keyword↔página. No inventes ese mapa. Para las
> filas `Reforzar`/`Mejorar` ancla en la hoja `Páginas` (el slug de la URL ya
> indica el tema). Para `Crear nuevo` ancla en la hoja `Consultas`.

**B) Conector/MCP de GSC en vivo.** Si está disponible, extrae con la
dimensión `page` (y `query` cuando se pueda) de los últimos 3-6 meses. Aquí sí
puedes obtener el mapa página→keyword real.

En ambos casos, selecciona:
- Páginas de **blog/informacionales** con **posición media entre 3 y 10** (la
  zona de impacto), con sus clics e impresiones reales.
- Keywords informacionales en zona de impacto sin artículo propio → `Crear nuevo`.

Filtra fuera del análisis:
- Páginas de producto/colección/servicio/transaccionales puras (el vídeo aporta poco).
- Páginas ya con vídeo embebido (evita duplicar trabajo — compruébalo con un
  `web_fetch` de la URL buscando un `<iframe>` de YouTube o schema
  `VideoObject`; no uses scripts que no existan en el entorno).
- Páginas por debajo de un umbral mínimo de impresiones (por defecto 50/mes o
  equivalente en el periodo del export; ajustable según el volumen del cliente).

### Paso 2 — Clasificación de Intención

Para cada página filtrada, clasifica la intención de la keyword principal:
informacional, comparativa, tutorial/cómo-hacer, transaccional o
navegacional. Descarta transaccional y navegacional del análisis de vídeo —
no se benefician del formato.

### Paso 3 — Validación de Demanda de Vídeo (DataForSEO)

Para cada keyword superviviente, valida la intención de vídeo en la SERP real
de YouTube. Por orden de preferencia:
1. **DataForSEO MCP** si está conectado (endpoint `serp_youtube_organic_live_advanced`).
2. **Si DataForSEO NO está disponible**, valida manualmente con `web_search`
   (p. ej. `"<keyword> youtube tutorial"`) mirando la SERP real de YouTube.
   Es un sustituto válido pero más lento; **déjalo anotado como limitación**
   en el Excel y recomienda reconfirmar con DataForSEO antes de escalar.

Nunca declares "demanda de vídeo validada" sin haber mirado de verdad la SERP
de YouTube (por MCP o por búsqueda). No lo asumas por intuición.

Extrae:
- ¿Aparecen resultados de vídeo relevantes para esta keyword? (si la SERP de
  YouTube está vacía o es irrelevante, esa keyword no tiene intención de
  vídeo real, descártala)
- Quién ya rankea (canales, duración media, antigüedad, formato de título)
- Nivel de competencia aproximado (canales grandes vs. huecos para canales
  pequeños)

### Paso 4 — Enriquecimiento con Semrush MCP

Para las keywords que superan el filtro de demanda de vídeo, usa Semrush MCP
(`keyword_research`) para:
- Volumen de búsqueda orientativo (de Google — tenlo en cuenta como proxy,
  no como cifra literal de YouTube)
- Keywords long-tail relacionadas para ampliar el guion/capítulos del vídeo
- Dificultad de keyword, como referencia adicional de esfuerzo

### Paso 5 — Clasificación en 3 Buckets

| Bucket | Criterio | Objetivo del vídeo |
|--------|----------|----------------------|
| **A — Reforzar (posición 3-5)** | La página ya está cerca del podio, la keyword tiene demanda de vídeo validada | Empujón final: embed arriba del pliegue + schema `VideoObject`. Prioridad alta, ejecución rápida |
| **B — Reforzar + Mejorar (posición 6-10)** | Potencial claro pero puede necesitar más que solo el vídeo | Embed + revisión de contenido/enlazado interno del artículo en paralelo. Marca como acción combinada, no solo vídeo |
| **C — Crear desde Cero** | No hay página que rankee para esa keyword, pero hay demanda de vídeo validada + volumen | Nace la pieza nueva: artículo y vídeo se publican juntos, reforzándose desde el origen |

Los tres buckets son lógica **interna** para decidir qué grabar y qué tipo de
acción toca. En el Excel NO se muestran como "A/B/C" sino traducidos a la
columna `Acción` (`Reforzar` / `Mejorar y reforzar` / `Crear nuevo`).

Para priorizar puedes calcular internamente una puntuación de oportunidad
(demanda por impresiones GSC, intención, facilidad y competencia débil en
YouTube), pero **no la vuelques como columna**: úsala solo para ordenar. El
orden final del Excel se hace por **impresiones GSC descendentes**, que es la
señal de demanda que el cliente entiende y en la que más se puede confiar
(recuerda que el volumen de Semrush infravalora el long-tail en español).

### Paso 6 — Enriquecimiento con Clustering (reutiliza seo-cluster)

Si hay varias oportunidades relacionadas temáticamente, aplica la misma
lógica de solapamiento de SERP de `seo-cluster` pero apuntada a la SERP de
YouTube en lugar de a la web. Esto agrupa vídeos en estructura pilar/spoke y
genera automáticamente qué vídeo debería enlazar a cuál (descripción,
tarjetas, pantalla final, playlist) — reutiliza
`skills/seo-cluster/references/serp-overlap-methodology.md` sustituyendo la
fuente de datos de SERP web por SERP de YouTube.

### Paso 7 — Notas de Sector (opcional, contextual)

Si el cliente pertenece a un vertical YMYL (salud, legal, finanzas —
reutiliza la detección de sector de `seo-audit`/`seo-local`), añade una nota
de E-E-A-T en el guion: necesidad de mostrar credenciales del presentador,
evitar promesas médicas/legales/financieras concretas, citar fuentes en
pantalla. No lo trates como un roadmap distinto, es una capa contextual
sobre el mismo proceso.

---

## ⛔ Reglas de integridad de datos (OBLIGATORIO)

Estas reglas están por encima de cualquier otra cosa. Un plan con datos
inventados no vale y hace perder la confianza del cliente.

1. **URLs reales y literales.** Cada URL de la columna `URL del blog` se copia
   EXACTAMENTE de la hoja `Páginas` de GSC (o del API). Prohibido inventar,
   adivinar, "deducir" o construir una URL a mano. Si no está en GSC, no existe
   para este plan.
2. **Cero cifras inventadas.** Posición, clics, impresiones y volumen salen SOLO
   de la fuente real (GSC / Semrush). Si un dato no está, deja la celda en
   blanco — nunca lo rellenes a ojo ni pongas un número "aproximado".
3. **Cero filas fantasma.** No añadas oportunidades que no tengan respaldo en
   los datos. Cada fila `Reforzar`/`Mejorar y reforzar` DEBE corresponder a una
   URL real presente en la hoja `Páginas`. Cada fila `Crear nuevo` DEBE nacer de
   una keyword real de la hoja `Consultas` con demanda de vídeo validada.
4. **Competencia real.** Los canales/vídeos de la columna de competencia salen
   de la SERP de YouTube consultada de verdad. No cites canales inventados.
5. **Títulos y esqueletos = propuesta, no dato.** Son creación tuya (con la voz
   `pedro-seo-brand-voice`), y está bien. Pero NUNCA mezcles creación con datos:
   los números y URLs siempre son reales.
6. **Verificación previa al guardado.** Antes de escribir el `.xlsx`, revisa
   fila por fila que (a) la URL existe en el export, y (b) posición/clics/
   impresiones coinciden con el export. Si algo no cuadra, corrígelo o elimínalo.

## Salida: Excel del Plan de Contenidos

Genera un archivo `.xlsx` (usa la skill `xlsx` del sistema para el formato)
con una fila por oportunidad. El objetivo es que sea **operativo**: un
calendario de vídeos que el equipo pueda ejecutar, no una matriz de análisis.

**Quédate solo con las oportunidades top.** Por defecto, prioriza las **~8-10
oportunidades de mayor impacto por impresiones GSC** y no infles la lista. Es
mejor un plan corto y accionable que un volcado de 20+ filas. El análisis
interno (intención, clustering, buckets, puntuación) se usa para **decidir y
ordenar**, pero NO se vuelca en columnas salvo lo indicado abajo.

Las columnas son EXACTAMENTE estas 12, en este orden:

| # | Columna | Descripción |
|---|---------|-------------|
| 1 | URL del blog | Página a reforzar, copiada literal de GSC. Si es contenido nuevo, pon `Crear nuevo` |
| 2 | **Estado del vídeo** | **Desplegable** (data validation tipo lista) con solo 3 valores: `Idea` · `En desarrollo` · `Publicado`. Todas las filas nacen en `Idea`. Va justo después de la URL |
| 3 | Posición actual | Posición media en Google (`—` si es contenido nuevo) |
| 4 | Clics | Clics actuales de la página en GSC — el tráfico que YA tiene |
| 5 | Impresiones | Impresiones de la página en GSC |
| 6 | Keyword principal | |
| 7 | Volumen Semrush (proxy) | De Semrush, marcado como proxy de Google, no de YouTube. Si Semrush no está, deja en blanco (nunca en cero) |
| 8 | Título del vídeo | 2-3 variantes con **gancho, curiosidad, número o CTA** (NO descriptivo plano), **cada variante en su propia línea** (salto de línea real, no separadas por ` \| `). Aplica la voz de `pedro-seo-brand-voice` |
| 9 | Duración estimada | Basada en la media de la competencia observada en YouTube |
| 10 | Esqueleto de vídeo | Bloques con timestamps, **un capítulo por línea** (salto de línea real, nunca todo seguido). No es guion palabra por palabra |
| 11 | Enlace a otros vídeos (tarjetas, pantallas finales...) | **Una sola columna** con los vídeos del plan a los que debería enlazar (tarjetas / pantallas finales / playlist), citados por su título. Usa `→` para "enlaza a" y `↔` para enlace mutuo |
| 12 | Fecha estimada de publicación | En blanco para que el equipo la rellene |

### Reglas de formato del Excel
- **`Estado del vídeo` es un desplegable de verdad** (validación de datos con
  lista `"Idea,En desarrollo,Publicado"`, `allow_blank=False`), no texto libre.
- **Formato condicional por `Estado del vídeo`**: la fila se colorea sola —
  gris = `Idea`, amarillo = `En desarrollo`, verde = `Publicado`.
- **Orden**: por **Impresiones GSC descendentes** (la demanda real).
- No añadas columnas de Acción, Competencia, Responsable, estados de
  embed/schema, fecha objetivo/real ni Resultado del 2x1: se eliminaron a
  propósito para mantener el Excel limpio y operativo. El seguimiento del 2x1
  vive fuera del calendario (se audita con `/seo youtube <url>` cuando toca).
- Añade una segunda hoja **"Método y notas"** con: qué es el SEO 2x1, cómo se
  seleccionaron las oportunidades, el significado de los estados, y la
  limitación de DataForSEO/Semrush si aplica.

---

## Salida: Resumen Ejecutivo en PowerPoint

Además del Excel (uso interno del equipo), genera un `.pptx` breve para
presentar al cliente (usa la skill `pptx` del sistema) con:

1. Portada + contexto del método (1 slide: qué es el SEO 2x1, en lenguaje
   simple para el cliente)
2. Resumen numérico: nº de oportunidades por tipo de acción, impresiones
   totales en juego, nº de piezas aptas también para Shorts
3. Top 5-10 oportunidades de tipo `Reforzar` (quick wins) con sus impresiones GSC
4. Top oportunidades de tipo `Crear nuevo` (piezas nuevas de mayor impacto)
5. Roadmap de publicación propuesto (por trimestre o sprint, según cadencia
   del cliente)
6. Próximos pasos

No incluyas en el PPTX el detalle de columnas de producción/interlinking —
eso se queda en el Excel para el equipo.

---

## Puntuación de Oportunidad — SOLO uso interno para ordenar (referencia rápida)

> No se muestra como columna en el Excel. Sirve únicamente para decidir el
> orden de prioridad si no quieres ordenar solo por impresiones.

| Componente | Peso orientativo |
|------------|----------------------|
| Volumen orientativo (Semrush) | 35% |
| Ajuste de intención (tutorial/comparativa > informacional genérica) | 20% |
| Facilidad (Bucket A > B > C, y dificultad de keyword inversa) | 25% |
| Competencia débil detectada en YouTube (huecos frente a canales grandes) | 20% |

Normaliza a una escala 0-100 para que sea comparable entre buckets y fácil
de priorizar en la reunión con el cliente.

---

## Integración Entre Skills

| Skill | Punto de Integración |
|-------|---------------------------|
| **seo-cluster** | Reutiliza la metodología de solapamiento de SERP para agrupar vídeos en pilar/spoke |
| **seo-youtube** | Audita el vídeo una vez publicado y alimenta la columna "Resultado del 2x1" |
| **seo-schema** | Genera el JSON-LD de `VideoObject` para cada embed |
| **seo-audit / seo-local** | Aporta la detección de sector para las notas de E-E-A-T |
| **pedro-seo-brand-voice** | Aplica la voz de marca a los títulos y borradores de descripción generados |
| **seo-dataforseo** | Fuente de la SERP real de YouTube y datos de competencia |

---

## Manejo de Errores

| Escenario | Acción |
|-----------|--------|
| Sin acceso a GSC del cliente | Informa que es un requisito indispensable del Paso 1; no se puede sustituir por Semrush/DataForSEO solos, porque son ellos los que dan el "casi-top" real |
| DataForSEO no disponible | Informa la limitación: no se puede validar demanda real de vídeo, y recomienda no publicar el plan sin esa validación aunque Semrush dé volumen alto |
| Semrush MCP no disponible | Continúa sin volumen orientativo ni long-tail adicional; señala la limitación en el Excel (columna de volumen en blanco, no en cero) |
| Cliente sin páginas en zona de impacto (todo en posición 1-2 o 11+) | Informa el hallazgo; recomienda centrar el plan casi por completo en Bucket C, o revisar el rango de posiciones de zona de impacto |
| Página del blog ya tiene vídeo embebido | Exclúyela automáticamente del Paso 1, no la propongas de nuevo |
| Keyword sin ninguna intención clara de vídeo en YouTube | Descarta esa fila del plan, no la fuerces dentro de un bucket |

## Descargo de Limitaciones

El volumen de Semrush es una señal de Google, no de YouTube — trátalo como
orientativo, no como número exacto de búsquedas dentro de YouTube. La
Puntuación de Oportunidad es una heurística de priorización, no una
predicción garantizada de resultado. El resultado real del "2x1" solo se
confirma auditando la posición del artículo antes/después de publicar el
vídeo (columna "Resultado del 2x1"), no en el momento de la planificación.
