# Arquitectura de Contenido Hub-and-Spoke

## Visión General de la Estructura

Un cluster hub-and-spoke consiste en una página pilar (el hub) conectada a múltiples
clusters spoke, cada uno con 2-4 posts individuales. El pilar ofrece una cobertura
amplia; los spokes profundizan en subtemas.

```
                    [Spoke 1a] --- [Spoke 1b]
                         \       /
                      [Cluster 1]
                           |
[Spoke 2a] -- [Cluster 2] -- [PILAR] -- [Cluster 3] -- [Spoke 3a]
[Spoke 2b] /                                        \ [Spoke 3b]
                           |
                      [Cluster 4]
                         /       \
                    [Spoke 4a] --- [Spoke 4b]
```

## Especificaciones de la Página Pilar

| Atributo | Requisito |
|----------|-----------|
| Recuento de palabras | 2.500-4.000 palabras |
| Keyword | La más amplia y de mayor volumen del conjunto |
| Tipo de contenido | Visión general completa que cubre todos los subtemas del cluster |
| Plantilla | `guía-definitiva` (por defecto) |
| Enlaces internos | Enlaza a CADA post spoke de cada cluster (obligatorio) |
| Estructura | Índice, una sección por cluster, resumen por subtema |
| Schema | Article + BreadcrumbList + ItemList (listando todas las páginas del cluster) |
| Frecuencia de actualización | Refrescar trimestralmente o cuando se añadan nuevos spokes |

## Especificaciones de la Página Spoke

| Atributo | Requisito |
|----------|-----------|
| Recuento de palabras | 1.200-1.800 palabras |
| Keyword | Keyword de subtema específica (única por post) |
| Tipo de contenido | Profundización en un único subtema |
| Plantilla | Seleccionada según la intención (ver mapeo de plantillas abajo) |
| Enlaces internos | Enlaza al pilar (obligatorio) + 2-3 spokes hermanos |
| Schema | Article + BreadcrumbList |
| Profundidad | Más detallado que la cobertura del pilar sobre el mismo subtema |

## Restricciones del Cluster

| Restricción | Valor |
|-------------|-------|
| Clusters por pilar | 2-5 |
| Posts por cluster | 2-4 |
| Total de posts (incluyendo el pilar) | 5-21 |
| Máximo total de palabras estimadas | ~50.000 (pilar + 20 spokes al máximo) |

## Selección Automática de Plantilla por Intención

| Patrón de Intención | Plantilla | Descripción |
|----------------------|-----------|--------------|
| Informacional (amplio) | `guía-definitiva` | Visión general completa del tema |
| Informacional (cómo) | `cómo-hacer` | Instrucciones paso a paso |
| Informacional (lista) | `listado` | Lista numerada de elementos/consejos |
| Informacional (concepto) | `explicativo` | Explicación profunda de un concepto |
| Comercial (comparar) | `comparativa` | Comparación lado a lado de productos/servicios |
| Comercial (evaluar) | `opinión` | Análisis en profundidad de un único producto/servicio |
| Comercial (rankear) | `top-mejores` | Lista rankeada de las mejores opciones |
| Transaccional | `landing-page` | Página enfocada en conversión |

**Lógica de selección:**
1. Relaciona la intención clasificada de la keyword con la tabla anterior
2. Si varias plantillas coinciden, prioriza la que se corresponda con el formato de contenido
   más habitual en el SERP (p. ej., si los primeros resultados son todos listados, usa `listado`)
3. Evita plantillas duplicadas dentro del mismo cluster salvo que la intención lo justifique

## Reglas de Enlazado Interno

### Enlaces Obligatorios
- Cada spoke DEBE enlazar al pilar (al menos una vez en el contenido del cuerpo)
- El pilar DEBE enlazar a cada spoke (en su sección correspondiente)
- No son negociables -- un cluster sin estos enlaces está estructuralmente roto

### Enlaces Recomendados
- Spoke a spoke dentro del mismo cluster: 2-3 enlaces por post
- Usa anchor text contextual (keyword objetivo o variante cercana)
- Coloca los enlaces dentro de los párrafos del cuerpo, no solo en secciones de "posts relacionados"

### Enlaces Opcionales
- Spoke a spoke entre clusters: 0-1 enlaces por post
- Solo cuando exista un puente temático genuino entre clusters
- Evita forzar enlaces cruzados que no aporten valor al lector

### Requisitos Mínimos de Enlazado
- Cada post debe tener al menos 3 enlaces internos entrantes
- Sin páginas huérfanas (toda página accesible desde el pilar en 2 clics)
- Diversidad de anchor text: ningún anchor text usado en más del 40% de los enlaces hacia una página

## Prevención de Canibalización

1. **Ningún par de posts comparte la misma keyword primaria.** Punto.
2. Si el solapamiento de SERP entre dos keywords es 7+, fusiónalas en un único post
3. Tras el clustering, verifica la unicidad: lista todas las keywords primarias y comprueba
   posibles cuasi-duplicados (p. ej., "mejor CRM" y "top software CRM")
4. Si se encuentran cuasi-duplicados, fusiona los posts o diferéncialos por intención
   (p. ej., uno como lista "top-mejores", otro como "comparativa")

## Plantillas de Schema JSON-LD

### Página Pilar
```json
[
  { "@type": "Article", "headline": "...", "author": {...}, "datePublished": "..." },
  { "@type": "BreadcrumbList", "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Inicio", "item": "..." },
    { "@type": "ListItem", "position": 2, "name": "Título del Pilar", "item": "..." }
  ]},
  { "@type": "ItemList", "name": "Cluster de Temas", "itemListElement": [
    { "@type": "ListItem", "position": 1, "url": "spoke-1-url" }
  ]}
]
```

### Página Spoke
```json
[
  { "@type": "Article", "headline": "...", "author": {...}, "isPartOf": { "@id": "pillar-url" } },
  { "@type": "BreadcrumbList", "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Inicio", "item": "..." },
    { "@type": "ListItem", "position": 2, "name": "Título del Pilar", "item": "pillar-url" },
    { "@type": "ListItem", "position": 3, "name": "Título del Spoke", "item": "..." }
  ]}
]
```

## Esquema de cluster-plan.json

```json
{
  "version": "1.9.0",
  "seed_keyword": "string",
  "created_at": "ISO-8601",
  "pillar": {
    "title": "string",
    "keyword": "string",
    "volume": 0,
    "template": "guía-definitiva",
    "wordCount": 4000,
    "url": "string",
    "status": "planned|written"
  },
  "clusters": [
    {
      "name": "Nombre del Cluster",
      "posts": [
        {
          "title": "string",
          "keyword": "string",
          "volume": 0,
          "template": "string",
          "wordCount": 1500,
          "url": "string",
          "status": "planned|written"
        }
      ]
    }
  ],
  "links": [
    { "from": "pillar", "to": "cluster-0-post-0", "type": "mandatory", "anchor": "keyword" }
  ],
  "serp_matrix": {
    "keywords": ["string"],
    "scores": [[0]]
  },
  "scorecard": {
    "coverage": 0.0,
    "linkDensity": 0.0,
    "orphanPages": 0,
    "cannibalization": 0,
    "contentGaps": 0
  }
}
```
