# Referencia de la API Merchant de DataForSEO

Detalles de endpoints para datos de marketplace de Google Shopping y Amazon.

## Endpoints

### Productos de Google Shopping

| Campo | Valor |
|-------|-------|
| Endpoint | `merchant_google_products_search` |
| Método | POST (tarea) / GET (resultados) |
| Coste | 0,02$ por llamada |
| Cola | Estándar (ahorro del 60-80% frente a live) |

**Parámetros:**
- `keyword` (obligatorio) -- consulta de búsqueda
- `location_code` (por defecto: 2840 = EE.UU.) -- ID de ubicación de DataForSEO
- `language_code` (por defecto: "en") -- idioma
- `price_min` / `price_max` (opcional) -- filtrar por rango de precio
- `sort_by` (opcional) -- "relevance", "price_low_to_high", "price_high_to_low", "rating"
- `depth` (opcional, por defecto: 100) -- número de resultados

**Campos de la respuesta:**
- `title` -- título del listado del producto
- `price` -- valor numérico del precio
- `currency` -- código de moneda (USD, EUR, etc.)
- `seller` -- nombre del comerciante
- `rating` -- valoración del producto (float, 0-5)
- `reviews_count` -- número de reseñas
- `url` -- URL del listado del producto
- `image_url` -- URL de la imagen del producto
- `availability` -- "in_stock", "out_of_stock", "preorder"
- `delivery_info` -- texto con los detalles de envío
- `product_id` -- ID del producto en Google Shopping

### Vendedores de Google Shopping

| Campo | Valor |
|-------|-------|
| Endpoint | `merchant_google_sellers_search` |
| Método | POST (tarea) / GET (resultados) |
| Coste | 0,02$ por llamada |

**Parámetros:** los mismos que en la búsqueda de productos.

**Campos de la respuesta:**
- `seller_name` -- nombre del comerciante
- `seller_rating` -- valoración del comerciante (float)
- `seller_reviews_count` -- número de reseñas del comerciante
- `price` -- precio ofrecido por este vendedor
- `delivery_info` -- texto de envío y entrega
- `url` -- URL del listado del vendedor

### Productos de Amazon

| Campo | Valor |
|-------|-------|
| Endpoint | `merchant_amazon_products_search` |
| Método | POST (tarea) / GET (resultados) |
| Coste | 0,02$ por llamada |
| Nota | Está en `warn_endpoints` -- siempre requiere aprobación del usuario |

**Parámetros:**
- `keyword` (obligatorio) -- consulta de búsqueda
- `location_code` (por defecto: 2840 = EE.UU.)
- `language_code` (por defecto: "en")
- `depth` (opcional, por defecto: 100)
- `sort_by` (opcional) -- "relevance", "price_low_to_high", "price_high_to_low", "avg_customer_review"

**Campos de la respuesta:**
- `title` -- título del producto
- `price` -- precio numérico
- `currency` -- código de moneda
- `seller` -- nombre del vendedor/marca
- `rating` -- valoración en estrellas (float, 0-5)
- `reviews_count` -- número de reseñas
- `url` -- URL del producto en Amazon
- `image_url` -- imagen del producto
- `availability` -- estado de stock
- `asin` -- Amazon Standard Identification Number
- `is_prime` -- elegibilidad Prime (booleano)
- `is_best_seller` -- insignia de Más Vendido (booleano)

## Patrón de Tarea/Sondeo

Todos los endpoints de Merchant usan el patrón estándar de cola de DataForSEO:

1. **POST** de la tarea con los parámetros para crear el endpoint
2. **Sondeo** de resultados con backoff exponencial (2s, 4s, 8s, máx. 60s)
3. **GET** de los resultados completados por ID de tarea

Esto ahorra entre un 60% y un 80% frente a los endpoints en vivo.

## Límites de Peticiones

- Máximo 2.000 tareas por minuto (en todos los endpoints)
- Máximo 30.000 tareas por día en los planes estándar
- Backoff ante HTTP 429: espera 60 segundos y reintenta

## Normalización de Datos

Al consumir las respuestas, normaliza:

| Campo | En Bruto | Normalizado |
|-------|----------|-------------|
| Precio | Cadena "29,99$" o float | Float `29.99` |
| Moneda | Formatos mixtos | Código ISO 4217 (USD, EUR, GBP) |
| Disponibilidad | Cadenas variadas | Enum: `in_stock`, `out_of_stock`, `preorder`, `unknown` |
| Valoración | Entero o float | Float redondeado a 1 decimal |
| Reseñas | Cadena o int | Entero |

Usa `scripts/dataforseo_normalize.py --module merchant` para la normalización automática.

## Referencia de Costes

Ver `skills/seo-dataforseo/references/cost-tiers.md` para la tabla completa de
precios, los presets de presupuesto y los consejos para reducir costes. Todos los
endpoints de Merchant cuestan 0,02$/llamada en la cola estándar.
