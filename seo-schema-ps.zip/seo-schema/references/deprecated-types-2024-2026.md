# Tipos de rich result de Schema.org obsoletos (2024–2026)

Referencia autorizada de todos los rich results que Google retiró durante la
limpieza de 2024–2025. Cuando un usuario pida alguno de estos tipos, la
skill `seo-schema` debe explicar que el tipo está obsoleto y bien
redirigir a una alternativa activa, bien señalar que no existe sustituto.

## Retirados el 19 de junio de 2025

Anunciado en
[Simplifying our Search rich results](https://developers.google.com/search/blog/2025/06/simplifying-search-results)
(developers.google.com/search/blog).

| Tipo | Retirado | Notas |
|---|---|---|
| **Vehicle Listing** (`@type: VehicleListing` / `Vehicle`) | Junio 2025 | Sin sustituto. Google ya no renderiza tarjetas rich de inventario de concesionarios. Usa el schema `Product` normal si el listado se vende online. |
| **Claim Review** (`@type: ClaimReview`) | Junio 2025 | Sin sustituto. El rich result de fact-check era el principal consumidor de ClaimReview; sin él, el marcado no tiene efecto en el SERP. El vocabulario *ClaimReview* sigue existiendo en schema.org, pero Google lo ignora. |
| **Estimated Salary** (`@type: EstimatedSalary` / `OccupationalAggregateRating`) | Junio 2025 | Sin sustituto. `JobPosting` sigue activo para ofertas de empleo individuales. |
| **Learning Video** | Junio 2025 | Sin sustituto. El rich result genérico de `VideoObject` sigue renderizándose. |
| **Carrusel de Course Info** | Junio 2025 | Se retiró la variante de carrusel. La tarjeta rich de resultado único `Course` sigue activa. Cuando te pidan "Course Info", verifica si el usuario quiere el carrusel (muerto) o la variante de resultado único activa. |

## Retirados el 31 de julio de 2025

| Tipo | Retirado | Notas |
|---|---|---|
| **Special Announcement** (`@type: SpecialAnnouncement`) | Julio 2025 | La tarjeta de información de emergencia de la era COVID quedó obsoleta. Sin sustituto. |

## Retiradas Anteriores (línea base pre-v2)

Se listan por completitud para que el modelo no las sugiera.

| Tipo | Retirado | Notas |
|---|---|---|
| **HowTo** (`@type: HowTo`) | Septiembre 2023 | Rich result eliminado en escritorio y móvil. El vocabulario permanece pero no produce ninguna función SERP. Algunos sitios siguen usando HowTo por su legibilidad para citación en IA — es una razón defendible para mantenerlo, pero márcalo como "sin efecto en SERP". |
| **FAQ** (`@type: FAQPage`) | Ago. 2023 (restringido); **7 de mayo de 2026 (retirado por completo)** | Rich results retirados por completo para **todos** los sitios el 7 de mayo de 2026 — esto sustituye a la restricción de gov/salud de 2023. El soporte del Rich Results Test/informes se retira en jun. 2026; la API de Search Console en ago. 2026. Marca el FAQPage existente como Info (no Crítico) porque sigue ayudando a la citación de IA/LLM como señal de entidad; **no** recomiendes eliminarlo ni añadir uno nuevo por beneficio en el SERP. Para páginas genuinas de una sola pregunta, usa `QAPage`. |

## Tabla de Decisión de Sustitución

Al generar schema, prioriza estas alternativas:

| Se pidió | Sustituto |
|---|---|
| `ClaimReview` | Ninguno — explica que el rich result está muerto; sugiere `Article` con `dateline` si es contexto de noticias. |
| `EstimatedSalary` | `JobPosting` con `baseSalary` para roles específicos. |
| `LearningVideo` | `VideoObject` (sigue activo). |
| Carrusel de `Course Info` | Tarjeta rich de `Course` de resultado único (sigue activa). |
| `SpecialAnnouncement` | `Event` si está acotado en el tiempo; si no, `Article` o `WebPage`. |
| `VehicleListing` | `Product` con propiedades específicas de vehículo. |
| `HowTo` (para SERP) | Ninguno — explica que el rich result está muerto. Sugiere una estructura de artículo con encabezados `<h2>` claros por paso si el objetivo es la comprensión; el beneficio de ranking ya no viene del schema. |
| `FAQPage` (para SERP) | Ninguno — rich results retirados en mayo de 2026. Mantén el marcado para citación en IA; usa `QAPage` para páginas genuinas de P&R enviadas por usuarios. |

## Fuentes Primarias

- Anuncio de retirada de Google (junio 2025): https://developers.google.com/search/blog/2025/06/simplifying-search-results
- Obsolescencia de Special Announcement (julio 2025): https://developers.google.com/search/blog
- Retirada de HowTo (septiembre 2023): https://developers.google.com/search/blog/2023/09/structured-data-changes
- Restricción de FAQ (agosto 2023): https://developers.google.com/search/blog/2023/08/howto-faq-changes
- Retirada del rich result de FAQ (7 de mayo de 2026): https://developers.google.com/search/docs/appearance/structured-data/faqpage

Última verificación contra developers.google.com: 25-05-2026.
