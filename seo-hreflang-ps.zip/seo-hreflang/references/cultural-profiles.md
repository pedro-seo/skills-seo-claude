# Perfiles de Adaptación Cultural para SEO Internacional

Carga esta referencia al analizar sitios multi-idioma o generar implementaciones
de hreflang. Los perfiles guían la evaluación cultural más allá de la validación técnica.

## Región DACH (DE, AT, CH)

| Dimensión | Directriz |
|-----------|-----------|
| Formalidad | Alta. Usar "Sie" (usted formal). Se espera un tono profesional. |
| Humor | Conservador. Evitar el sarcasmo y los juegos de palabras en los CTA. |
| Estilo de CTA | Se prefiere indirecto. "Jetzt entdecken" (descúbrelo ahora) frente a "Jetzt kaufen" (compra ahora). |
| Señales de Confianza | Certificaciones (TÜV, ISO), "Datenschutz" (privacidad), Impressum obligatorio por ley. |
| Legal | Página de Impressum obligatoria. DSGVO (RGPD). Widerrufsrecht (derecho de desistimiento). |
| Formato de Número | 1.000,00 (punto para miles, coma para decimales) |
| Formato de Fecha | DD.MM.AAAA |
| Moneda | EUR (DE/AT), CHF (CH) |
| Simbolismo del Color | Azul = confianza, Verde = eco/naturaleza, Rojo = precaución (no urgencia) |
| Sustitución de Marca | Walmart → MediaMarkt, Home Depot → Hornbach, Amazon → Otto/Zalando |
| Expansión de Palabras | +25-35% frente al inglés (prever titulares y botones más largos) |

## Francófono (FR, BE, CA-FR, CH-FR)

| Dimensión | Directriz |
|-----------|-----------|
| Formalidad | Media-alta. "Vous" por defecto. "Tu" solo para marcas juveniles/informales. |
| Humor | Apreciado cuando es sofisticado. Evitar el humor brusco/directo. |
| Estilo de CTA | Redacción elegante. "Découvrir nos solutions" frente a "Achetez maintenant". |
| Señales de Confianza | "Fabriqué en France", certificaciones profesionales, menciones en prensa. |
| Legal | Mentions légales obligatorias. CNIL (protección de datos). CGV (condiciones). |
| Formato de Número | 1 234,56 (espacio para miles, coma para decimales) |
| Formato de Fecha | DD/MM/AAAA |
| Moneda | EUR (FR/BE), CAD (CA-FR), CHF (CH-FR) |
| Simbolismo del Color | Azul = estabilidad, Blanco = pureza/lujo, Rojo = pasión |
| Sustitución de Marca | Walmart → Carrefour, Amazon → Fnac/Cdiscount, Target → Leclerc |
| Expansión de Palabras | +15-25% frente al inglés |

## Hispano (ES, LATAM)

| Dimensión | Directriz |
|-----------|-----------|
| Formalidad | Varía según el país. España: "Usted" formal. LATAM: mixto. |
| Humor | Cercano y relacional. Se acepta el humor autocrítico. |
| Estilo de CTA | Cercano, personal. "Empieza tu viaje" frente a "Comprar ahora". |
| Señales de Confianza | Prueba social comunitaria, temas de familia/relaciones, endorsement de celebridades popular. |
| Legal | LOPD (protección de datos en España). Cada país de LATAM tiene su propia normativa. |
| Formato de Número | España: 1.000,00 / LATAM: varía según el país |
| Formato de Fecha | DD/MM/AAAA (la mayoría), DD-MM-AAAA (algunos países LATAM) |
| Moneda | EUR (ES), monedas regionales (MXN, ARS, COP, CLP, PEN) |
| Simbolismo del Color | Rojo = energía/pasión, Amarillo = calidez, Azul = confianza |
| Sustitución de Marca | Walmart → Mercadona (ES) / Coppel (MX), Amazon → MercadoLibre |
| Expansión de Palabras | +15-25% frente al inglés |

## Japonés (JA)

| Dimensión | Directriz |
|-----------|-----------|
| Formalidad | Muy alta. Se espera keigo (lenguaje honorífico) en el ámbito profesional. |
| Humor | Sutil. Evitar el humor directo en B2B. Elementos kawaii (tiernos) aceptables en B2C. |
| Estilo de CTA | Sutil y educado. "Otoiawase" (consultar) frente al directo "comprar ahora". |
| Señales de Confianza | Antigüedad de la empresa, certificaciones ISO, respaldo de instituciones reconocidas. |
| Legal | APPI (Ley de Protección de Información Personal). Ley Tokutei Shotorihiki. |
| Formato de Número | 1,000 (coma para miles, sin decimales en la mayoría de contextos) |
| Formato de Fecha | AAAA/MM/DD o AAAA年MM月DD日 |
| Moneda | JPY (sin decimales) |
| Simbolismo del Color | Blanco = pureza, Rojo = vitalidad/celebración, Negro = formalidad |
| Sustitución de Marca | Amazon → Rakuten, Google Shopping → Yahoo! Shopping Japan |
| Contracción de Palabras | -10-25% frente al inglés (el japonés es más compacto) |

## Perfil por Defecto (Idiomas No Listados)

Al analizar un locale sin un perfil ya preparado:

1. **Investiga las normas de formalidad**: comprueba si el idioma tiene registros formal/informal (p. ej., el coreano tiene 7 niveles de habla)
2. **Comprueba la dirección del texto**: LTR vs RTL (árabe, hebreo, farsi, urdu)
3. **Verifica los formatos de número/fecha**: usa CLDR (Unicode Common Locale Data Repository)
4. **Investiga los requisitos legales**: ley de privacidad, registro empresarial, protección al consumidor
5. **Comprueba el ratio de expansión de palabras**: las lenguas germánicas/eslavas expanden, las lenguas CJK contraen
6. **Verifica moneda y preferencias de pago**: los métodos de pago locales pueden necesitar mención
7. **Investiga el significado de los colores**: los colores tienen asociaciones culturales distintas globalmente

## Cómo Usarlo en el Análisis

Al ejecutar `/seo hreflang` en un sitio multi-idioma:
1. Identifica todas las versiones de idioma y sus mercados objetivo
2. Carga el/los perfil(es) cultural(es) relevante(s)
3. Comprueba que los CTA, las señales de confianza y las páginas legales coinciden con las expectativas culturales
4. Marca las discrepancias como hallazgos de "Adaptación Cultural" (severidad Media)
5. Comprueba la consistencia del formato de número/fecha/moneda dentro de cada versión de locale
