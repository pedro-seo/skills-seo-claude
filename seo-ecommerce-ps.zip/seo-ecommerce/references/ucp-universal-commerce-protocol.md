# UCP — Universal Commerce Protocol (Mayo 2026)

UCP es un estándar abierto liderado por Google, co-desarrollado con Shopify y
respaldado por Etsy, Target, Walmart, Wayfair, además de socios de pago (Stripe, Visa,
Mastercard, Adyen, Amex). Su propósito: permitir que los **agentes de IA descubran,
negocien y transaccionen con comerciantes sin integraciones a medida**.

Para los sitios de comercio, UCP se sitúa junto a los **feeds de Google Merchant Center**
y **Google Business Profile** como la tercera pata del descubrimiento en la era de agentes.
La adopción está en fase temprana, pero el coste de declarar un perfil es bajo.

**Fuente primaria:** la guía de optimización para IA de Google hace referencia a UCP; la
especificación en sí se copublica en developer.google.com / merchant.google.com (consulta
a Google para la URL canónica actual — el estándar está en movimiento).

## Qué es y qué no es UCP

| Qué es | Qué no es |
|---|---|
| Un protocolo de declaración de capacidades + negociación | Un nuevo procesador de pagos |
| Agnóstico de transporte (REST, MCP, A2A) | Un sustituto de los feeds de Merchant Center |
| Compatible con AP2 (Agent Payments Protocol) para prueba criptográfica de consentimiento del usuario en compras autónomas | Una forma de dejar de ser el comerciante de registro |
| Adoptado hoy por AI Mode en Search y Gemini | Un "factor de ranking" — Google no lo ha planteado así |

Los comerciantes siguen siendo **Merchant of Record** bajo UCP — mantienen las
relaciones con los clientes y la propiedad post-compra.

## Cómo declarar un perfil UCP

Publica un perfil en `/.well-known/ucp` describiendo capacidades y versiones.
La forma general (consulta la especificación en vivo para los nombres exactos de los campos):

```jsonc
{
  "version": "1.0",
  "capabilities": [
    {
      "id": "dev.ucp.shopping.checkout",
      "version": "1.0",
      "endpoint": "https://api.ejemplo.com/ucp/checkout"
    },
    {
      "id": "dev.ucp.shopping.fulfillment",
      "version": "1.0",
      "endpoint": "https://api.ejemplo.com/ucp/fulfillment"
    },
    {
      "id": "dev.ucp.shopping.discount",
      "version": "1.0",
      "endpoint": "https://api.ejemplo.com/ucp/discount"
    }
  ],
  "merchant": {
    "name": "Ejemplo S.L.",
    "id": "id-de-merchant-center-aqui"
  }
}
```

Las plataformas (AI Mode en Search, Gemini y eventualmente otras) descubren
automáticamente el perfil y negocian. Google ha construido una implementación de
referencia que impulsa la compra directa desde AI Mode y Gemini.

## Capacidades Comunes a Declarar

| ID de Capacidad (forma) | Propósito |
|---|---|
| `dev.ucp.shopping.checkout` | Inicia el checkout, devuelve totales + intención de pago |
| `dev.ucp.shopping.fulfillment` | Cotiza opciones de envío y ventanas de entrega |
| `dev.ucp.shopping.discount` | Aplica códigos promocionales / descuentos de fidelización en el momento de la cotización |
| `dev.ucp.shopping.cart` | Añade / elimina / actualiza artículos en carritos gestionados por agentes |

Los identificadores exactos se rigen por la especificación en vivo. El patrón es
`dev.ucp.<dominio>.<verbo>` con versionado semántico.

## Qué Audita Esta Skill

`/seo ecommerce <url>` debe informar de:

1. **Presencia:** ¿resuelve `/.well-known/ucp` a un documento JSON válido?
2. **Cobertura de capacidades:** ¿qué capacidades están declaradas? Marca la ausencia
   de checkout / fulfillment / discount como oportunidad, no como fallo (el
   protocolo está en fase temprana).
3. **Accesibilidad de endpoints:** ¿los endpoints declarados son HTTPS, con TLS válido, sin
   devolver errores 5xx?
4. **Coherencia de versión:** ¿la versión de protocolo declarada coincide con una
   release conocida? Marca versiones pre-release o no reconocidas.

La auditoría **no debería** puntuar la ausencia de UCP como un fallo crítico hoy en día
— la adopción está en fase temprana. Enmárcalo como una oportunidad de cara al futuro,
especialmente para comerciantes que ya están en Google Merchant Center.

## Cómo Interactúa UCP con las Superficies Existentes

| Superficie Existente | Relación con UCP |
|---|---|
| Feed de Google Merchant Center | Requisito previo — las capacidades de UCP referencian productos de Merchant Center por ID |
| Google Business Profile | Independiente — UCP es de producto/pedido; GBP es de tienda/ubicación |
| Schema de Product (`hasMerchantReturnPolicy`, `shippingDetails`) | Complementario — UCP expone los mismos datos en la capa de API; el schema los expone en la capa de página |
| AP2 (Agent Payments Protocol) | Pareja — UCP gestiona el descubrimiento + la estructura de checkout; AP2 gestiona la prueba criptográfica de consentimiento del usuario |

Un comerciante que ya tenga feeds de Merchant Center limpios, schema de Product
completo y una API de checkout puede declarar un perfil UCP en un sprint.

## Postura de Auditoría

- **Nivel 1 (sitios de e-commerce ya en Merchant Center):** recomienda
  declarar un perfil UCP como oportunidad de cara al futuro.
- **Nivel 2 (sitios DTC que no están en Merchant Center):** no recomiendes UCP todavía —
  Merchant Center es el requisito previo para la mayoría de los flujos.
- **Nivel 3 (sitios informativos / B2B):** ignora UCP por completo.

## Última Verificación

18-05-2026. El estándar avanza rápido. Vuelve a comprobarlo cuando:

- La URL canónica de la especificación se estabilice (actualmente publicada en la
  documentación de desarrolladores de Google, pero la ruta exacta puede cambiar).
- AP2 alcance una versión estable.
- Otras plataformas (más allá de AI Mode + Gemini) anuncien el consumo de UCP.
