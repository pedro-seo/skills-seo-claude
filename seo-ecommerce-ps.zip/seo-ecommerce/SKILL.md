---
name: seo-ecommerce
description: >
  Análisis de SEO para e-commerce: visibilidad en Google Shopping, inteligencia
  de marketplace de Amazon, validación de schema de producto, análisis de precios
  de competidores y vacíos de keywords de marketplace. Combina el SEO on-page de
  producto con datos de marketplace de la API Merchant de DataForSEO. Úsala cuando
  el usuario diga "SEO ecommerce", "SEO de producto", "Google Shopping",
  "SEO de marketplace", "schema de producto", "SEO Amazon", "listados de producto",
  "shopping ads" o "SEO merchant".
user-invocable: true
argument-hint: "<url o keyword>"
license: MIT
compatibility: "Mejorada con la API Merchant de DataForSEO (opcional)"
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Análisis de SEO para E-commerce

Optimización completa de páginas de producto, inteligencia de marketplace y
análisis competitivo de precios. Funciona de forma independiente (on-page +
schema) y con la API Merchant de DataForSEO para datos en vivo de Google
Shopping y Amazon.

## Comandos

| Comando | Propósito | ¿DataForSEO? |
|---------|-----------|--------------|
| `/seo ecommerce <url>` | Análisis SEO completo de e-commerce de una página de producto o tienda | Opcional |
| `/seo ecommerce products <keyword>` | Análisis competitivo de Google Shopping | Obligatorio |
| `/seo ecommerce gaps <domain>` | Gap de keywords: visibilidad orgánica vs. Shopping | Obligatorio |
| `/seo ecommerce schema <url>` | Validación y mejora del schema de producto | No |

---

## 1. Análisis de Página de Producto (Sin Necesidad de DataForSEO)

Obtiene y analiza cualquier página de producto para valorar su calidad SEO on-page.

### Flujo de Trabajo

```
1. python3 scripts/render_page.py <url> --mode auto → HTML en bruto/renderizado
2. python3 scripts/parse_html.py --url <url>   → elementos SEO
3. Analiza las señales específicas de producto (abajo)
```

### Checklist de SEO de Producto

#### Title Tag
- [ ] Contiene la keyword de producto primaria
- [ ] Incluye el nombre de la marca
- [ ] Menos de 60 caracteres (sin truncamiento en el SERP)
- [ ] Formato: `[Nombre del Producto] - [Característica Clave] | [Marca]`

#### Meta Description
- [ ] Contiene la keyword del producto + un beneficio
- [ ] Incluye el precio o "desde XX€" (despierta interés de rich snippet)
- [ ] Presenta una llamada a la acción (Compra ahora, Comprar, Envío gratis)
- [ ] Menos de 155 caracteres

#### Estructura de Encabezados
- [ ] Un único H1 que coincida con el nombre principal del producto
- [ ] H2 para: Características, Especificaciones, Reseñas, Productos Relacionados
- [ ] Sin H1 duplicados entre variantes de producto

#### Imágenes de Producto
- [ ] El alt text incluye el nombre del producto + característica distintiva
- [ ] Los nombres de archivo son descriptivos (no `IMG_001.jpg`)
- [ ] Se sirve en formato WebP (con fallback a JPEG)
- [ ] Al menos 3 imágenes por producto (hero, detalle, lifestyle)
- [ ] Dimensiones de imagen >= 800px para elegibilidad en Google Shopping
- [ ] Lazy loading solo en imágenes por debajo del pliegue

#### Enlazado Interno
- [ ] Navegación de breadcrumbs: Inicio > Categoría > Subcategoría > Producto
- [ ] Sección de productos relacionados (cross-sell / upsell)
- [ ] Enlace de vuelta a la página de categoría con anchor rico en keywords
- [ ] La sección de reseñas enlaza a la página completa de reseñas (si es distinta)

#### Calidad del Contenido
- [ ] Descripción de producto única (no copiada del fabricante)
- [ ] Recuento de palabras >= 200 en el cuerpo de la descripción del producto
- [ ] Tabla de especificaciones presente (no solo prosa)
- [ ] Reseñas de usuarios en la página (señales UGC)

### Puntuación

| Categoría | Peso | Criterio |
|-----------|------|----------|
| Completitud del schema | 25% | Campos obligatorios + recomendados de Product |
| Título y meta | 15% | Colocación de keyword, longitud, formato |
| Optimización de imágenes | 20% | Alt text, formato, tamaño, cantidad |
| Calidad del contenido | 20% | Descripción única, specs, reseñas |
| Enlazado interno | 10% | Breadcrumbs, productos relacionados, categorías |
| Técnico | 10% | Velocidad de página, renderizado móvil, canonical |

---

## 2. Inteligencia de Google Shopping (API Merchant de DataForSEO)

Análisis competitivo en vivo a partir de los resultados de Google Shopping.

### Control de Coste (OBLIGATORIO)

Antes de CADA llamada a la API Merchant:
```bash
python3 scripts/dataforseo_costs.py check merchant_google_products_search
```

- `"status": "approved"` -- continuar
- `"status": "needs_approval"` -- mostrar el coste, preguntar al usuario
- `"status": "blocked"` -- detenerse, informar al usuario

Tras cada llamada:
```bash
python3 scripts/dataforseo_costs.py log merchant_google_products_search <coste>
```

### Flujo de Trabajo

```bash
# Búsqueda de productos: quién vende qué y a qué precio
python3 scripts/dataforseo_merchant.py search "<keyword>" --marketplace google

# Análisis de vendedores: valoraciones y dominancia de comerciantes
python3 scripts/dataforseo_merchant.py sellers "<keyword>"

# Normaliza los resultados para el análisis
python3 scripts/dataforseo_normalize.py results.json --module merchant
```

### Resultados del Análisis

#### Inteligencia de Precios
- Distribución de precios: mín, máx, mediana, P25, P75
- Valores atípicos de precio (> 2 desviaciones estándar de la mediana)
- Correlación precio-valoración
- Normalización de moneda a EUR (o la que especifique el usuario)

#### Panorama de Vendedores
- Top 10 vendedores por número de listados
- Distribución de valoraciones de comerciante
- Prevalencia de envío gratuito
- Vendedores nuevos vs. establecidos

#### Calidad de los Listados de Producto
- Patrones de keyword en el título de los listados principales
- Benchmarks de valoración media y número de reseñas
- Número de imágenes por listado
- Distribución del estado de disponibilidad

Carga `references/marketplace-endpoints.md` para los detalles completos de parámetros de la API.

---

## 3. Marketplace de Amazon (DataForSEO)

Inteligencia cruzada de marketplace comparando Google Shopping y Amazon.

### Control de Coste (OBLIGATORIO)

```bash
python3 scripts/dataforseo_costs.py check merchant_amazon_products_search
```

Los endpoints de Amazon están en el conjunto `warn_endpoints` -- siempre requieren la aprobación del usuario.

### Flujo de Trabajo

```bash
# Búsqueda de productos en Amazon
python3 scripts/dataforseo_merchant.py search "<keyword>" --marketplace amazon

# Comparación cruzada de marketplace
python3 scripts/dataforseo_merchant.py compare "<keyword>"
```

### Informe Cruzado de Marketplace

| Métrica | Google Shopping | Amazon |
|---------|------------------|--------|
| Precio medio | € | € |
| Valoración mediana | X,X | X,X |
| Nº medio de reseñas | N | N |
| Cuota del vendedor principal | % | % |
| % de envío gratuito | % | % |

---

## 4. Vacíos de Keywords de Marketplace

Identifica desajustes entre la visibilidad orgánica y la de Shopping.

### Flujo de Trabajo

1. Obtén los rankings orgánicos vía seo-dataforseo:
   `dataforseo_labs_google_ranked_keywords` para el dominio
2. Obtén la presencia en Google Shopping vía la API Merchant:
   `merchant_google_products_search` para las principales keywords orgánicas
3. Cruza los resultados

### Tipos de Vacío

| Tipo de Vacío | Significado | Acción |
|-----------------|-------------|--------|
| **Solo Orgánico** | Posiciona orgánicamente pero sin anuncios de Shopping | Crear feed de Google Merchant Center, pujar por estas keywords |
| **Solo Shopping** | Visibilidad en Shopping pero orgánico débil/inexistente | Crear contenido (guías de compra, páginas de comparación) para estas keywords |
| **Ambos Presentes** | Visible en ambos canales | Optimizar: asegurar consistencia de precios, mejorar el schema |
| **Ninguno** | Sin visibilidad en ninguno | Baja prioridad salvo volumen alto |

### Formato de Salida

```
## Análisis de Gap de Keywords: ejemplo.com

### Oportunidades: Orgánico → Shopping (12 keywords)
| Keyword | Pos. Orgánica | Volumen | CPC | Acción Recomendada |
|---------|----------------|---------|-----|------------------------|

### Oportunidades: Shopping → Orgánico (8 keywords)
| Keyword | Ranking en Shopping | Volumen | CPC | Tipo de Contenido Necesario |
|---------|------------------------|---------|-----|--------------------------------|
```

---

## 5. Mejora del Schema de Producto

Valida y genera schema de Product siguiendo los requisitos actuales de Google.

### Propiedades Obligatorias (Google Merchant)

```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "",
  "image": [""],
  "description": "",
  "brand": { "@type": "Brand", "name": "" },
  "offers": {
    "@type": "Offer",
    "url": "",
    "priceCurrency": "EUR",
    "price": "0.00",
    "availability": "https://schema.org/InStock",
    "seller": { "@type": "Organization", "name": "" }
  }
}
```

### Propiedades Recomendadas (Mejoran los Rich Results)

- `sku` -- identificador de producto
- `gtin13` / `gtin14` / `mpn` -- identificadores de comercio globales
- `aggregateRating` -- valoración en estrellas + número de reseñas
- `review` -- reseñas individuales (mínimo 1)
- `color`, `material`, `size` -- atributos de variante
- `shippingDetails` -- ShippingDetails con tarifa y tiempo de entrega
- `hasMerchantReturnPolicy` -- MerchantReturnPolicy con tipo y días

### Reglas de Validación

1. `price` debe ser una cadena numérica, no "29,99€" (sin símbolo de moneda)
2. `availability` debe usar la URL completa del enum de Schema.org
3. `image` debe ser un array con >= 1 URL de imagen en alta resolución
4. `priceCurrency` debe ser ISO 4217 (EUR, USD, GBP)
5. `brand.name` no debe estar vacío ni ser "N/A"
6. Las fechas en `priceValidUntil` deben estar en ISO 8601
7. Si `aggregateRating` está presente: `ratingValue` y `reviewCount` son obligatorios

### Puntuación del Schema

| Completitud | Puntuación |
|-------------|------------|
| Todos los campos obligatorios | 50/100 |
| + aggregateRating | 65/100 |
| + sku/gtin/mpn | 75/100 |
| + shippingDetails | 85/100 |
| + merchantReturnPolicy | 90/100 |
| + reseñas (3+) | 100/100 |

---

## Integración Entre Skills

| Skill | Punto de Integración |
|-------|---------------------------|
| **seo-schema** | Delega la generación de schema de Product; reutiliza la lógica de validación |
| **seo-images** | Auditoría de imágenes de producto (alt text, formato, dimensiones) — más la etiqueta IPTC `DigitalSourceType: TrainedAlgorithmicMedia` para imágenes de producto generadas por IA (requisito de Merchant Center) |
| **seo-content** | Análisis de E-E-A-T y unicidad de la descripción de producto |
| **seo-dataforseo** | Rankings orgánicos de keywords para el análisis de gap |
| **seo-technical** | Core Web Vitals de páginas de producto (LCP en la imagen hero) |
| **seo-google** | Validación del feed de Google Merchant Center vía GSC |

## UCP — Universal Commerce Protocol (de cara al futuro)

Estándar liderado por Google (co-desarrollado con Shopify, Etsy, Walmart, Wayfair, Visa,
Mastercard, etc.) para que los agentes de IA puedan descubrir, negociar y transaccionar con
comerciantes sin integraciones a medida. Ya impulsa la compra directa desde AI
Mode y Gemini.

Los comerciantes que ya están en **Google Merchant Center** con un schema de Product
limpio pueden declarar un perfil UCP en `/.well-known/ucp` listando las capacidades
(`dev.ucp.shopping.checkout`, `.fulfillment`, `.discount`). Ver
`references/ucp-universal-commerce-protocol.md` para los criterios de auditoría,
ejemplos de capacidades y la relación con AP2 (Agent Payments Protocol).

### Comando de auditoría

```bash
# Descubre y valida el perfil UCP
python3 scripts/ucp_check.py https://tienda.ejemplo.com --json

# Con sondeos de accesibilidad de endpoints (HEAD a cada capacidad declarada)
python3 scripts/ucp_check.py https://tienda.ejemplo.com --probe-endpoints --json
```

El script devuelve: presencia del perfil, versión, capacidades declaradas,
problemas estructurales (campos faltantes, IDs de capacidad desconocidos) y (con
`--probe-endpoints`) la accesibilidad por endpoint. Los endpoints bloqueados por SSRF se
informan explícitamente. Un perfil ausente se informa como oportunidad, no como fallo
— la adopción de UCP está en fase temprana.

---

## Manejo de Errores

| Error | Causa | Respuesta |
|-------|-------|-----------|
| No se encontró schema de Product | La página carece de JSON-LD | Analiza el contenido de la página, genera el schema recomendado |
| Faltan credenciales de DataForSEO | Variables de entorno no configuradas | Ejecuta el análisis sin datos de marketplace, señala la limitación |
| Comprobación de coste bloqueada | Presupuesto diario superado | Informa al usuario, ofrece análisis solo gratuito |
| Resultados de Shopping vacíos | Sin productos para la keyword | Sugiere una keyword más amplia, comprueba la configuración de ubicación |
| Timeout de la API de Amazon | Red/límite de peticiones | Reintenta con backoff, recurre solo a Google |
| URL inválida | Entrada malformada | Valida vía `google_auth.validate_url()`, muestra el error |
| Página que no es de producto | La URL es de categoría/home | Detecta el tipo de página, sugiere `/seo ecommerce schema` en su lugar |

---

## Plantilla de Salida

```
## Informe de SEO de E-commerce: [URL o Keyword]

### Puntuación Global: XX/100

### SEO de Página de Producto
- Completitud del Schema: XX/100
- Título y Meta: XX/100
- Optimización de Imágenes: XX/100
- Calidad del Contenido: XX/100
- Enlazado Interno: XX/100

### Inteligencia de Marketplace (si DataForSEO está disponible)
- Listados en Google Shopping: N productos encontrados
- Rango de Precios: XX€ - XX€ (mediana: XX€)
- Vendedor Principal: [nombre] (XX% de cuota de mercado)
- Comparación con Amazon: [disponible/no comprobada]

### Principales Recomendaciones
1. [Crítico] ...
2. [Alto] ...
3. [Medio] ...

¿Genero un informe PDF? Usa `/seo google report`
```
