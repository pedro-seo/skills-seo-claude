# Catálogo de Herramientas MCP de DataForSEO

> Carga esta referencia cuando necesites encontrar una herramienta MCP específica de
> DataForSEO que no esté cubierta por los comandos principales del SKILL.md. Son
> herramientas de utilidad disponibles para uso interno pero sin comandos dedicados
> de `/seo dataforseo`.

## Utilidades de SERP

- `serp_locations`: búsqueda de códigos de ubicación para consultas de SERP
- `serp_youtube_locations`: búsqueda de códigos de ubicación para consultas de YouTube

## Utilidades de Datos de Keywords

- `kw_data_google_ads_locations`: búsqueda de ubicaciones para datos de keywords
- `kw_data_dfs_trends_demography`: datos demográficos para análisis de tendencias
- `kw_data_dfs_trends_subregion_interests`: datos de interés por subregión para tendencias
- `kw_data_dfs_trends_explore`: datos de tendencias propios de DFS
- `kw_data_google_trends_categories`: búsqueda de categorías de Google Trends

## Utilidades de DataForSEO Labs

- `dataforseo_labs_google_keyword_overview`: resumen rápido de métricas de keyword
- `dataforseo_labs_google_historical_serp`: resultados históricos de SERP para una keyword
- `dataforseo_labs_google_serp_competitors`: competidores para un SERP específico
- `dataforseo_labs_google_keywords_for_site`: keywords por las que posiciona un sitio (alternativa a ranked)
- `dataforseo_labs_google_page_intersection`: análisis de intersección a nivel de página
- `dataforseo_labs_google_historical_rank_overview`: datos históricos de rank de dominio
- `dataforseo_labs_google_historical_keyword_data`: métricas históricas de keywords
- `dataforseo_labs_available_filters`: opciones de filtro disponibles para los endpoints de Labs

## Utilidades de Backlinks

- `backlinks_competitors`: encuentra dominios con perfiles de backlinks similares
- `backlinks_bulk_backlinks`: recuentos de backlinks en bloque para varios objetivos
- `backlinks_bulk_new_lost_referring_domains`: dominios referentes nuevos/perdidos en bloque
- `backlinks_bulk_new_lost_backlinks`: backlinks nuevos/perdidos en bloque
- `backlinks_bulk_ranks`: resumen de rank en bloque para varios objetivos
- `backlinks_bulk_referring_domains`: recuentos de dominios referentes en bloque
- `backlinks_domain_pages_summary`: resumen de páginas de un dominio
- `backlinks_domain_pages`: lista de páginas de un dominio con datos de backlinks
- `backlinks_page_intersection`: fuentes de backlinks compartidas a nivel de página
- `backlinks_referring_networks`: análisis de redes referentes
- `backlinks_timeseries_new_lost_summary`: seguimiento de backlinks nuevos/perdidos a lo largo del tiempo
- `backlinks_bulk_pages_summary`: resúmenes de páginas en bloque
- `backlinks_available_filters`: opciones de filtro disponibles para los endpoints de Backlinks

## Utilidades de Domain Analytics

- `domain_analytics_whois_available_filters`: opciones de filtro para WHOIS
- `domain_analytics_technologies_available_filters`: opciones de filtro para detección de tecnología

## Utilidades de AI Optimization

- `ai_opt_kw_data_loc_and_lang`: ubicaciones/idiomas de datos de keywords para optimización de IA
- `ai_optimization_keyword_data_search_volume`: datos de volumen de keywords específicos para IA
- `ai_optimization_llm_response`: análisis directo de respuestas LLM
- `ai_optimization_llm_mentions_filters`: filtros disponibles para menciones LLM
- `ai_optimization_chat_gpt_scraper_locations`: ubicaciones disponibles para el scraper de ChatGPT
