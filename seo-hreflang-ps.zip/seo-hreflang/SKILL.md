---
name: seo-hreflang
description: >
  Auditoría, validación y generación de hreflang y SEO internacional. Detecta
  errores comunes, valida códigos de idioma/región y genera implementaciones
  correctas de hreflang. Úsala cuando el usuario diga "hreflang", "SEO i18n",
  "SEO internacional", "multi-idioma", "multi-región" o "etiquetas de idioma".
user-invocable: true
argument-hint: "[url]"
license: MIT
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Hreflang y SEO Internacional

Valida implementaciones de hreflang existentes o genera etiquetas hreflang
correctas para sitios multi-idioma y multi-región. Soporta implementaciones
en HTML, cabeceras HTTP y sitemap XML.

## Comprobaciones de Validación

### 1. Etiquetas Autorreferenciadas
- Toda página debe incluir una etiqueta hreflang que apunte a sí misma
- La URL autorreferenciada debe coincidir exactamente con la URL canónica de la página
- Las etiquetas autorreferenciadas ausentes hacen que Google ignore todo el conjunto de hreflang

### 2. Etiquetas de Retorno
- Si la página A enlaza a la página B con hreflang, la página B debe enlazar de vuelta a la página A
- Toda relación de hreflang debe ser bidireccional (A→B y B→A)
- Las etiquetas de retorno ausentes invalidan la señal de hreflang para ambas páginas
- Comprueba que todas las versiones de idioma se referencian entre sí (malla completa)

### 3. Etiqueta x-default
- Obligatoria: designa la página de fallback para idiomas/regiones no coincidentes
- Normalmente apunta a la página del selector de idioma o a la versión en inglés
- Solo un x-default por conjunto de alternates
- También debe tener etiquetas de retorno desde todas las demás versiones de idioma

### 4. Validación de Código de Idioma
- Debe usar códigos ISO 639-1 de dos letras (p. ej., `en`, `fr`, `de`, `ja`)
- Errores comunes:
  - `eng` en lugar de `en` (ISO 639-2, no válido para hreflang)
  - `jp` en lugar de `ja` (código incorrecto para japonés)
  - `zh` sin calificador de región (ambiguo; usar `zh-Hans` o `zh-Hant`)

### 5. Validación de Código de Región
- El calificador de región opcional usa ISO 3166-1 Alpha-2 (p. ej., `en-US`, `en-GB`, `pt-BR`)
- Formato: `idioma-REGIÓN` (idioma en minúsculas, región en mayúsculas)
- Errores comunes:
  - `en-uk` en lugar de `en-GB` (UK no es un código ISO 3166-1 válido)
  - `es-LA` (Latinoamérica no es un país; usar países específicos)
  - Región sin prefijo de idioma

### 6. Alineación con la URL Canónica
- Las etiquetas hreflang solo deben aparecer en URLs canónicas
- Si una página tiene `rel=canonical` apuntando a otro lugar, el hreflang de esa página se ignora
- La URL canónica y la URL de hreflang deben coincidir exactamente (incluidas las barras finales)
- Las páginas no canónicas no deben estar en ningún conjunto de hreflang

### 7. Consistencia de Protocolo
- Todas las URLs de un conjunto de hreflang deben usar el mismo protocolo (HTTPS o HTTP)
- Mezclar HTTP/HTTPS en los conjuntos de hreflang provoca fallos de validación
- Tras una migración a HTTPS, actualiza todas las etiquetas hreflang a HTTPS

### 8. Soporte Multi-Dominio
- Hreflang funciona entre dominios distintos (p. ej., ejemplo.com y ejemplo.de)
- El hreflang multi-dominio requiere etiquetas de retorno en ambos dominios
- Verifica que ambos dominios estén verificados en Google Search Console
- Se recomienda la implementación basada en sitemap para configuraciones multi-dominio

## Errores Comunes

| Problema | Severidad | Solución |
|----------|-----------|----------|
| Falta la etiqueta autorreferenciada | Crítico | Añadir hreflang que apunte a la URL de la misma página |
| Faltan etiquetas de retorno (A→B pero no B→A) | Crítico | Añadir etiquetas de retorno coincidentes en todos los alternates |
| Falta x-default | Alto | Añadir x-default apuntando a la página de fallback/selector |
| Código de idioma inválido (p. ej., `eng`) | Alto | Usar códigos ISO 639-1 de dos letras |
| Código de región inválido (p. ej., `en-uk`) | Alto | Usar códigos ISO 3166-1 Alpha-2 |
| Hreflang en una URL no canónica | Alto | Mover el hreflang solo a la URL canónica |
| Discrepancia HTTP/HTTPS en las URLs | Medio | Estandarizar todas las URLs a HTTPS |
| Inconsistencia en la barra final | Medio | Que coincida exactamente con el formato de la URL canónica |
| Hreflang tanto en HTML como en sitemap | Bajo | Elegir un único método (sitemap preferido para sitios grandes) |
| Idioma sin región cuando es necesaria | Bajo | Añadir el calificador de región para contenido geolocalizado |

## Métodos de Implementación

### Método 1: Etiquetas Link de HTML
Ideal para: sitios con menos de 50 variantes de idioma/región por página.

```html
<link rel="alternate" hreflang="en-US" href="https://ejemplo.com/pagina" />
<link rel="alternate" hreflang="en-GB" href="https://ejemplo.co.uk/pagina" />
<link rel="alternate" hreflang="fr" href="https://ejemplo.com/fr/pagina" />
<link rel="alternate" hreflang="x-default" href="https://ejemplo.com/pagina" />
```

Colócalas en la sección `<head>`. Toda página debe incluir todos los alternates, incluida ella misma.

### Método 2: Cabeceras HTTP
Ideal para: archivos no HTML (PDFs, documentos).

```
Link: <https://ejemplo.com/pagina>; rel="alternate"; hreflang="en-US",
      <https://ejemplo.com/fr/pagina>; rel="alternate"; hreflang="fr",
      <https://ejemplo.com/pagina>; rel="alternate"; hreflang="x-default"
```

Se configura vía servidor o reglas de CDN.

### Método 3: Sitemap XML (Recomendado para sitios grandes)
Ideal para: sitios con muchas variantes de idioma, configuraciones multi-dominio, o 50+ páginas.

Ver la sección Generación de Sitemap Hreflang más abajo.

### Comparativa de Métodos
| Método | Ideal Para | Ventajas | Desventajas |
|--------|------------|----------|-------------|
| Etiquetas link de HTML | Sitios pequeños (<50 variantes) | Fácil de implementar, visible en el código fuente | Satura el `<head>`, difícil de mantener a escala |
| Cabeceras HTTP | Archivos no HTML | Funciona para PDFs, imágenes | Configuración de servidor compleja, no visible en el HTML |
| Sitemap XML | Sitios grandes, multi-dominio | Escalable, gestión centralizada | No visible en la página, requiere mantenimiento del sitemap |

## Generación de Hreflang

### Proceso
1. **Detectar idiomas**: rastrea el sitio en busca de indicadores de idioma (ruta de URL, subdominio, TLD, atributo lang del HTML)
2. **Mapear páginas equivalentes**: haz coincidir las páginas correspondientes entre idiomas/regiones
3. **Validar códigos de idioma**: verifica todos los códigos contra ISO 639-1 e ISO 3166-1
4. **Generar etiquetas**: crea etiquetas hreflang para cada página, incluida la autorreferenciada
5. **Verificar etiquetas de retorno**: confirma que todas las relaciones son bidireccionales
6. **Añadir x-default**: define el fallback para cada conjunto de páginas
7. **Salida**: genera el código de implementación (HTML, cabeceras HTTP, o sitemap XML)

## Generación de Sitemap Hreflang

### Sitemap con Hreflang
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  <url>
    <loc>https://ejemplo.com/pagina</loc>
    <xhtml:link rel="alternate" hreflang="en-US" href="https://ejemplo.com/pagina" />
    <xhtml:link rel="alternate" hreflang="fr" href="https://ejemplo.com/fr/pagina" />
    <xhtml:link rel="alternate" hreflang="de" href="https://ejemplo.de/pagina" />
    <xhtml:link rel="alternate" hreflang="x-default" href="https://ejemplo.com/pagina" />
  </url>
  <url>
    <loc>https://ejemplo.com/fr/pagina</loc>
    <xhtml:link rel="alternate" hreflang="en-US" href="https://ejemplo.com/pagina" />
    <xhtml:link rel="alternate" hreflang="fr" href="https://ejemplo.com/fr/pagina" />
    <xhtml:link rel="alternate" hreflang="de" href="https://ejemplo.de/pagina" />
    <xhtml:link rel="alternate" hreflang="x-default" href="https://ejemplo.com/pagina" />
  </url>
</urlset>
```

Reglas clave:
- Incluye la declaración del namespace `xmlns:xhtml`
- Toda entrada `<url>` debe incluir TODOS los alternates de idioma (incluida ella misma)
- Cada alternate debe aparecer como una entrada `<url>` separada con su propio conjunto completo
- Divide en archivos de 50.000 URLs por sitemap

## Salida

### Informe de Validación de Hreflang

#### Resumen
- Total de páginas escaneadas: XX
- Variantes de idioma detectadas: XX
- Problemas encontrados: XX (Crítico: X, Alto: X, Medio: X, Bajo: X)

#### Resultados de Validación
| Idioma | URL | Autorref. | Etiquetas de Retorno | x-default | Estado |
|--------|-----|-----------|------------------------|-----------|--------|
| en-US | https://... | ✅ | ✅ | ✅ | ✅ |
| fr | https://... | ❌ | ⚠️ | ✅ | ❌ |
| de | https://... | ✅ | ❌ | ✅ | ❌ |

### Etiquetas Hreflang Generadas
- Etiquetas `<link>` de HTML (si se elige el método HTML)
- Valores de cabecera HTTP (si se elige el método de cabecera)
- `hreflang-sitemap.xml` (si se elige el método de sitemap)

### Recomendaciones
- Implementaciones faltantes a añadir
- Códigos incorrectos a corregir
- Sugerencias de migración de método (p. ej., de HTML a sitemap por escala)

## Evaluación de Adaptación Cultural

Al analizar un sitio multi-idioma, ve más allá de la validación técnica de hreflang para
evaluar si el contenido está culturalmente adaptado a cada mercado objetivo.

Carga `references/cultural-profiles.md` para perfiles ya preparados (DACH, Francófono, Hispano, Japonés).

**Pasos de evaluación:**
1. Identifica todas las versiones de idioma y sus mercados objetivo
2. Carga el/los perfil(es) cultural(es) relevante(s)
3. Comprueba que los CTA coinciden con las expectativas culturales (directo vs. indirecto)
4. Comprueba que las señales de confianza son adecuadas al locale (certificaciones, páginas legales)
5. Comprueba si hay referencias a marcas extranjeras en páginas localizadas
6. Comprueba la consistencia del formato de número/fecha/moneda
7. Marca los problemas de adaptación cultural con severidad Media

**Salida:** Puntuación de Adaptación Cultural por versión de idioma (0-100) con hallazgos específicos.

## Auditoría de Paridad de Contenido

**Comando:** `/seo hreflang audit <directorio-o-url>`

Audita la paridad de contenido entre todas las versiones de idioma de un sitio o directorio de contenido local.

Carga `references/content-parity.md` para la matriz de paridad completa y la metodología de puntuación.

**Qué comprueba:**
- Existencia de la página en todos los idiomas declarados
- Equivalencia de la estructura de secciones (recuento de H2/H3)
- Paridad de elementos SEO (título, meta, localización del schema)
- Validación del ratio de recuento de palabras (DE debería ser un 25-35% más largo que EN, JA un 10-25% más corto)
- Seguimiento de frescura (traducciones obsoletas detectadas mediante timestamps)
- Escaneo de marcadores culturales (marcas extranjeras, referencias legales erróneas, elementos sin traducir)

**Salida:** tabla de matriz de paridad con puntuaciones por página y acciones priorizadas.

## Validación de Formato de Locale

Carga `references/locale-formats.md` para las tablas de referencia de formato de número, fecha,
moneda, dirección y teléfono por locale.

**Comprobaciones:**
- Consistencia de formato numérico (p. ej., "1,000.00" debería ser "1.000,00" en páginas de-DE)
- El formato de fecha coincide con las expectativas del locale
- Símbolos de moneda y su colocación correctos para el mercado objetivo
- Los números de teléfono usan formato internacional con el código de país correcto

## Archivos de Referencia

Cárgalos bajo demanda según se necesiten (NO cargar todos al inicio):
- `references/cultural-profiles.md`: perfiles de adaptación cultural DACH, Francófono, Hispano, Japonés
- `references/locale-formats.md`: tablas de formato de número, fecha, moneda, dirección y teléfono por locale
- `references/content-parity.md`: metodología y puntuación de la auditoría de paridad de contenido

## Manejo de Errores

| Escenario | Acción |
|-----------|--------|
| URL inaccesible (fallo de DNS, conexión rechazada) | Informa el error con claridad. No inventes la estructura del sitio. Sugiere al usuario verificar la URL y volver a intentarlo. |
| No se encontraron etiquetas hreflang | Informa de la ausencia. Comprueba si hay otras señales de internacionalización (subdirectorios, subdominios, ccTLDs) y recomienda el método de implementación de hreflang adecuado. |
| Códigos de idioma/región inválidos detectados | Lista cada código inválido con su sustituto correcto. Proporciona un conjunto de etiquetas hreflang corregido y listo para implementar. |
| No hay perfil cultural disponible para el idioma | Usa la checklist del Perfil por Defecto de cultural-profiles.md. Señala que la evaluación se basa en directrices generales, no en un perfil ya preparado. |
| Directorio de paridad de contenido vacío | Informa de que no se encontraron archivos de contenido. Sugiere verificar la ruta del directorio o proporcionar una URL para el análisis del sitio en vivo. |
