# Flujo de Ejecución

## Visión General

La fase de ejecución transforma un `cluster-plan.json` en contenido real. Gestiona
el orden de prioridad, la inyección de contexto para el redactor de blog, la actualización de
enlaces hacia atrás, la capacidad de reanudación y la puntuación de calidad post-ejecución.

## Algoritmo de Prioridad

El contenido se crea en este orden estricto:

1. **Primero la página pilar** -- el hub debe existir antes de que ningún spoke pueda enlazarlo
2. **Spokes por volumen de búsqueda (descendente)** -- los spokes de mayor volumen primero para
   maximizar el impacto temprano
3. **En caso de mismo volumen, por índice de cluster** -- procesar el Cluster 0 antes que el Cluster 1
4. **Dentro del mismo cluster, por índice de post** -- procesar el Post 0 antes que el Post 1

Justificación: el pilar establece la base de autoridad temática. Los spokes de alto
volumen generan más tráfico orgánico, por lo que deben publicarse cuanto antes
para obtener retornos compuestos más rápido.

## Inyección de Contexto de Cluster

Al invocar `blog-write` para cada post, pasa un bloque de contexto estructurado:

```json
{
  "cluster_context": {
    "role": "pillar|spoke",
    "pillar_title": "La Guía Completa de ...",
    "pillar_url": "/guia/...",
    "cluster_name": "Nombre del Cluster",
    "cluster_index": 0,
    "post_index": 0,
    "primary_keyword": "keyword objetivo",
    "secondary_keywords": ["variante 1", "variante 2"],
    "template": "cómo-hacer",
    "word_count_target": 1500,
    "outgoing_links": [
      { "url": "/pillar-url", "anchor": "guía principal del tema", "type": "mandatory" },
      { "url": "/sibling-post", "anchor": "subtema relacionado", "type": "recommended" }
    ],
    "incoming_link_placeholder": "<!-- cluster-link:cluster-0-post-1 -->",
    "differentiation_note": "Este post debe centrarse en X, mientras que el post hermano cubre Y"
  }
}
```

### Explicación de los Campos de Contexto

| Campo | Propósito |
|-------|-----------|
| `role` | Si es el pilar o un spoke (afecta la profundidad y amplitud) |
| `pillar_title` / `pillar_url` | Para que los spokes puedan enlazar de vuelta al pilar |
| `cluster_name` / `cluster_index` | Para organización y etiquetado |
| `post_index` | Posición dentro del cluster |
| `primary_keyword` | La keyword objetivo principal de este post |
| `secondary_keywords` | Keywords adicionales a incorporar de forma natural |
| `template` | Plantilla de contenido a seguir (cómo-hacer, listado, comparativa, etc.) |
| `word_count_target` | Recuento de palabras objetivo (no un límite estricto, es orientativo) |
| `outgoing_links` | Enlaces que este post DEBE incluir, con anchor text sugerido |
| `incoming_link_placeholder` | Marcador de comentario HTML para la futura inyección de enlace hacia atrás |
| `differentiation_note` | En qué se diferencia este post de sus hermanos que apuntan a temas similares |

## Inyección de Enlaces Hacia Atrás

Después de escribir cada post nuevo, actualiza los posts previamente escritos para que enlacen a él:

### Proceso

1. Lee la matriz de enlaces de `cluster-plan.json`
2. Identifica todos los posts que deberían enlazar AL post recién escrito
3. Para cada uno de esos posts (que ya esté escrito):
   a. Abre el archivo del post
   b. Busca el comentario placeholder: `<!-- cluster-link:POST_ID -->`
   c. Sustituye el placeholder por un enlace contextual real
   d. Si no se encuentra ningún placeholder, añade un enlace contextual en la sección más relevante
4. Registra todos los enlaces hacia atrás añadidos

### Formato del Placeholder

```html
<!-- cluster-link:cluster-0-post-1 -->
```

Esto se inserta durante la creación de contenido en una ubicación contextualmente apropiada.
Cuando el post objetivo se escribe más adelante, el placeholder se sustituye por:

```html
Para profundizar más, consulta nuestra guía sobre <a href="/target-url">anchor text</a>.
```

## Capacidad de Reanudación

La ejecución puede interrumpirse y reanudarse. El algoritmo de reanudación:

### Detección

1. Lee `cluster-plan.json` del directorio actual
2. Escanea el directorio de salida en busca de archivos de post existentes
3. Compara los archivos encontrados con el plan usando:
   - Patrones de nombre de archivo (slug derivado del título o keyword)
   - Inspección de contenido (comprueba `primary_keyword` en el frontmatter o el primer H1)
4. Marca los posts coincidentes como `"status": "written"` en el plan

### Lógica de Reanudación

1. Carga el plan con los estados actualizados
2. Filtra solo los posts con `"status": "planned"`
3. Aplica el algoritmo de prioridad a los posts restantes
4. Continúa la ejecución desde el siguiente post no escrito
5. Ejecuta la inyección de enlaces hacia atrás para cualquier enlace entre posts recién
   escritos y posts previamente escritos

### Casos Límite

- Si falta el pilar pero existen spokes, escribe primero el pilar y luego
  inyecta enlaces hacia atrás en los spokes existentes
- Si un archivo de spoke existe pero está incompleto (menos del 50% del recuento de palabras objetivo),
  trátalo como no escrito y recréalo
- Si `cluster-plan.json` se ha modificado desde la última ejecución, revalida
  el plan antes de reanudar

## Métricas del Scorecard

Al completar la ejecución (o bajo demanda), genera `cluster-scorecard.md`:

### Definiciones de Métricas

| Métrica | Fórmula | Objetivo |
|---------|---------|----------|
| Cobertura | `posts_escritos / posts_planificados * 100` | 100% |
| Densidad de Enlaces | `total_enlaces_internos / total_posts` | >= 3.0 por post |
| Páginas Huérfanas | Cuenta de posts con 0 enlaces internos entrantes | 0 |
| Conectividad al Pilar | `spokes_que_enlazan_al_pilar / total_spokes * 100` | 100% |
| Enlaces Inversos del Pilar | `spokes_enlazados_desde_el_pilar / total_spokes * 100` | 100% |
| Enlaces Cruzados | `enlaces_cruzados_implementados / enlaces_cruzados_recomendados * 100` | >= 80% |
| Canibalización | Cuenta de posts que comparten una keyword primaria | 0 |
| Nº de Imágenes | Posts con al menos una imagen / total de posts | >= 90% |
| Vacíos de Contenido | Posts planificados aún no escritos | 0 |
| Recuento Medio de Palabras | Media de palabras en todos los posts escritos | Dentro del 10% de los objetivos |

### Formato de Salida del Scorecard

```markdown
# Scorecard del Cluster: [Keyword Semilla]

## Resumen
- Posts: X/Y escritos (Z%)
- Palabras totales: N (estimadas: M)
- Enlaces internos: L (densidad: L/Y por post)

## Métricas
| Métrica | Puntuación | Estado |
|---------|------------|--------|
| Cobertura | 100% | PASS |
| Densidad de Enlaces | 3.2/post | PASS |
| ...

## Problemas Encontrados
- [Lista cualquier métrica en FAIL o WARN con pasos de solución]

## Próximos Pasos
- [Elementos accionables para alcanzar el 100% en todas las métricas]
```

## Puertas de Calidad

Antes de marcar la ejecución como completa, verifica:

1. Cada spoke enlaza al pilar (obligatorio)
2. El pilar enlaza a cada spoke (obligatorio)
3. Ningún post tiene menos de 3 enlaces internos entrantes
4. Ningún par de posts comparte la misma keyword primaria
5. No existen páginas huérfanas
6. Todos los posts cumplen el recuento mínimo de palabras (80% del objetivo)

Si falla alguna puerta, márcalo en el scorecard y proporciona instrucciones
específicas de solución. No apruebes silenciosamente un cluster que falle.
