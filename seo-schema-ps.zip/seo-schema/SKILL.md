---
name: seo-schema
description: >
  Detecta, valida y genera datos estructurados de Schema.org. Se prefiere el
  formato JSON-LD. Úsala cuando el usuario diga "schema", "datos
  estructurados", "rich results", "JSON-LD" o "marcado".
user-invocable: true
argument-hint: "[url]"
license: MIT
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Análisis y Generación de Marcado de Schema

## Detección

1. Rastrea el código fuente de la página en busca de JSON-LD `<script type="application/ld+json">`
2. Comprueba si hay Microdata (`itemscope`, `itemprop`)
3. Comprueba si hay RDFa (`typeof`, `property`)
4. Recomienda siempre JSON-LD como formato principal (preferencia declarada de Google)

## Validación

- Comprueba las propiedades obligatorias según el tipo de schema
- Valida contra los tipos de rich result soportados por Google
- Comprueba errores comunes:
  - `@context` ausente
  - `@type` inválido
  - Tipos de datos incorrectos
  - Texto de relleno
  - URLs relativas (deberían ser absolutas)
  - Formatos de fecha inválidos
- Marca los tipos obsoletos (ver abajo)

## Estado de los Tipos de Schema (a mayo de 2026)

Lee `references/schema-types.md` para la lista completa. Reglas clave:

### ACTIVOS (recomendar libremente):
Organization, LocalBusiness, SoftwareApplication, WebApplication, Product (con marcado de Certification desde abril de 2025), ProductGroup, Offer, Service, Article, BlogPosting, NewsArticle, Review, AggregateRating, BreadcrumbList, WebSite, WebPage, Person, ProfilePage, ContactPage, VideoObject, ImageObject, Event, JobPosting, Course, DiscussionForumPosting

### VÍDEO Y ESPECIALIZADOS (recomendar libremente):
BroadcastEvent, Clip, SeekToAction, SoftwareSourceCode

Ver `schema/templates.json` para plantillas JSON-LD listas para usar de estos tipos.

> **JSON-LD y renderizado con JavaScript:** según la guía de JS SEO de Google de diciembre de 2025, los datos estructurados inyectados vía JavaScript pueden sufrir un procesamiento retrasado. Para marcado sensible al tiempo (especialmente Product, Offer), incluye el JSON-LD en el HTML renderizado por el servidor desde el inicio.

### SIN RICH RESULTS — SE MANTIENE PARA IA:
- **FAQPage**: Google retiró los rich results de FAQ para TODOS los sitios el 7 de mayo de 2026 (sustituye a la restricción de gov/salud de agosto de 2023). Ya no hay función SERP — pero marca el FAQPage existente como Info (no Crítico), ya que el marcado sigue ayudando a la resolución de entidades de AI Mode / AI Overviews. Para páginas genuinas de P&R de usuarios, usa **QAPage**.

### OBSOLETOS (nunca recomendar):
- **HowTo**: rich results eliminados en septiembre de 2023
- **SpecialAnnouncement**: obsoleto desde el 31 de julio de 2025
- **CourseInfo, EstimatedSalary, LearningVideo**: retirados en junio de 2025
- **ClaimReview**: retirado de los rich results en junio de 2025
- **VehicleListing**: retirado de los rich results en junio de 2025
- **Practice Problem**: retirado de los rich results a finales de 2025
- **Dataset**: retirado de los rich results a finales de 2025
- **Book Actions**: obsoleto y luego revertido, sigue funcional a fecha de feb. 2026 (nota histórica)

## Generación

Al generar schema para una página:
1. Identifica el tipo de página a partir del análisis del contenido
2. Selecciona el/los tipo(s) de schema apropiado(s)
3. Genera JSON-LD válido con todas las propiedades obligatorias + recomendadas
4. Incluye solo datos veraces y verificables. Usa placeholders claramente marcados para que el usuario los rellene
5. Valida la salida antes de presentarla

## Plantillas Comunes de Schema

### Organization
```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "[Nombre de la Empresa]",
  "url": "[URL de la Web]",
  "logo": "[URL del Logo]",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "[Teléfono]",
    "contactType": "customer service"
  },
  "sameAs": [
    "[URL de Facebook]",
    "[URL de LinkedIn]",
    "[URL de Twitter]"
  ]
}
```

### LocalBusiness
```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "[Nombre del Negocio]",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "[Calle]",
    "addressLocality": "[Ciudad]",
    "addressRegion": "[Provincia]",
    "postalCode": "[Código Postal]",
    "addressCountry": "ES"
  },
  "telephone": "[Teléfono]",
  "openingHours": "Mo-Fr 09:00-17:00",
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "[Lat]",
    "longitude": "[Long]"
  }
}
```

### Article/BlogPosting
```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "[Título]",
  "author": {
    "@type": "Person",
    "name": "[Nombre del Autor]"
  },
  "datePublished": "[AAAA-MM-DD]",
  "dateModified": "[AAAA-MM-DD]",
  "image": "[URL de la Imagen]",
  "publisher": {
    "@type": "Organization",
    "name": "[Editor]",
    "logo": {
      "@type": "ImageObject",
      "url": "[URL del Logo]"
    }
  }
}
```

## Salida

- `SCHEMA-REPORT.md`: resultados de detección y validación
- `generated-schema.json`: fragmentos JSON-LD listos para usar

### Resultados de Validación
| Schema | Tipo | Estado | Problemas |
|--------|------|--------|-----------|
| ... | ... | ✅/⚠️/❌ | ... |

### Recomendaciones
- Oportunidades de schema faltante
- Correcciones de validación necesarias
- Código generado para la implementación

## Manejo de Errores

| Escenario | Acción |
|-----------|--------|
| URL inaccesible | Informa del error de conexión con el código de estado. Sugiere verificar la URL y comprobar si la página requiere autenticación. |
| No se encontró marcado de schema | Informa de que no se detectó JSON-LD, Microdata ni RDFa. Recomienda los tipos de schema apropiados según el análisis del contenido de la página. |
| Sintaxis de JSON-LD inválida | Analiza e informa de los errores de sintaxis específicos (llaves faltantes, comas finales, claves sin comillas). Proporciona el JSON-LD corregido. |
| Tipo de schema obsoleto detectado | Marca el tipo obsoleto con su fecha de retirada. Recomienda el tipo de sustitución actual o aconseja eliminarlo si no existe sustituto. |
