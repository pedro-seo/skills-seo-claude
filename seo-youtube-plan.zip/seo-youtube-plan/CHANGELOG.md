# Changelog — seo-youtube-plan

## 1.2.0
- Excel reducido a 12 columnas fijas y más operativo. El plan se queda por
  defecto con las ~8-10 oportunidades top por impresiones (no volcado extenso).
- Eliminadas columnas: Acción, Competencia YouTube detectada, Estado del embed,
  Estado del schema, Responsable, Fecha objetivo, Fecha real y Resultado del 2x1.
- "Estado del vídeo" ahora es un DESPLEGABLE (validación de datos) con 3 valores:
  Idea / En desarrollo / Publicado, colocado justo tras la URL, con formato
  condicional (gris / amarillo / verde).
- "Enlaza a" + "Enlazado desde" fusionadas en una sola columna
  "Enlace a otros vídeos (tarjetas, pantallas finales...)".
- Título del vídeo: cada variante en su propia línea (antes separadas por " | ").
- Añadida hoja "Método y notas" obligatoria en el Excel.

## 1.1.0
- Excel más operativo: fuera ID, Bucket (código), Cluster, Pilar/Spoke,
  Keywords secundarias, Intención, KD, Puntuación de Oportunidad, Borrador de
  descripción, Apto Shorts, Notas E-E-A-T, Playlist y Acción sobre el artículo.
- Nueva columna "Clics (GSC)" junto a Impresiones.
- "Bucket A/B/C" → columna "Acción" en texto claro (Reforzar / Mejorar y
  reforzar / Crear nuevo).
- "Título de trabajo" → "Título del vídeo" con gancho/CTA estilo YouTube.
- Esqueleto de vídeo: un capítulo por línea (salto de línea real).
- Orden del Excel por impresiones GSC descendentes.
- Paso 1 reescrito: soporta export .xlsx de GSC subido por el usuario, con las
  hojas reales (Páginas / Consultas). URLs copiadas literales, nunca inventadas.
- Nueva sección "Reglas de integridad de datos": prohibido inventar URLs,
  cifras, filas o competencia. Verificación previa al guardado.
- Eliminadas referencias a scripts inexistentes (render_page.py,
  dataforseo_costs.py). DataForSEO ahora es MCP con fallback a web_search.

## 1.0.0
- Versión inicial.
