# Auditoría de Paridad de Contenido para Sitios Multi-Idioma

Carga esta referencia al auditar la paridad de contenido entre versiones de idioma
de un sitio. La paridad de contenido asegura que todas las versiones de idioma
aportan un valor y unas señales SEO equivalentes.

## Matriz de Paridad de Contenido

Para cada página que existe en varios idiomas, comprueba:

| Dimensión | Qué Comparar | Variación Aceptable | Severidad si Falla |
|-----------|----------------|-------------------------|------------------------|
| Existencia de la página | ¿Existe la página equivalente en todos los idiomas declarados? | 0% — todos los idiomas declarados deben tener la página | Alta |
| Estructura de secciones | ¿Mismo número de secciones H2/H3? | ±1 sección permitida | Media |
| Elementos de FAQ | ¿Mismo número de preguntas de FAQ? | ±2 elementos permitidos | Media |
| Imágenes | ¿Mismo número de imágenes con alt text localizado? | Debe coincidir exactamente | Media |
| Gráficos/SVGs | ¿Presentes los gráficos en todas las versiones? | Debe coincidir exactamente | Baja |
| Recuento de palabras | ¿Proporcional al ratio de expansión del idioma? | ±30% del ratio esperado | Baja |
| Marcado de schema | ¿JSON-LD presente y localizado en todas las versiones? | Debe coincidir el tipo y las propiedades clave | Alta |
| Title tag | ¿Localizado con la keyword objetivo en el idioma local? | Debe estar localizado, no en inglés | Alta |
| Meta description | ¿Localizada y dentro del límite de caracteres? | Debe estar localizada | Media |

## Seguimiento de Frescura

Detecta traducciones obsoletas comparando:
1. **Timestamps de modificación de archivo**: si la versión EN se actualizó después que la versión DE, la DE puede estar obsoleta
2. **Fechas del frontmatter**: compara `date_modified` o `lastmod` entre versiones de idioma
3. **Comparación de hash de contenido**: si el hash del contenido del idioma origen cambió desde la última traducción

Umbrales de delta de frescura:
- **Fresco**: traducido dentro de los 7 días posteriores a la actualización de origen → OK
- **Envejeciendo**: 8-30 días desde la actualización de origen → actualización de baja prioridad
- **Obsoleto**: 31-90 días desde la actualización de origen → actualización de prioridad media
- **Desactualizado**: 90+ días desde la actualización de origen → actualización de alta prioridad

## Validación del Ratio de Recuento de Palabras

Ratios de recuento de palabras esperados frente al origen en inglés:

| Idioma Objetivo | Ratio Esperado | Rango Aceptable |
|--------------------|--------------------|------------------------|
| Alemán (DE) | 1,25-1,35x | 1,10-1,50x |
| Francés (FR) | 1,15-1,25x | 1,00-1,40x |
| Español (ES) | 1,15-1,25x | 1,00-1,40x |
| Japonés (JA) | 0,75-0,90x | 0,60-1,00x |
| Chino (ZH) | 0,70-0,80x | 0,55-0,95x |

Una traducción al alemán más corta que el original en inglés probablemente tenga contenido faltante.
Una traducción al japonés más larga que el inglés probablemente tenga relleno innecesario.

## Puertas de Calidad de Adaptación Cultural

Más allá de la traducción directa, comprueba marcadores culturales que indiquen una localización adecuada:

| Comprobación | Qué Buscar | Severidad |
|--------------|--------------|-----------|
| Referencias a marcas extranjeras | Marcas específicas de EE.UU. en páginas no estadounidenses (p. ej., "Walmart" en de-DE) | Media |
| Estadísticas extranjeras | Datos exclusivos de EE.UU. citados en páginas localizadas (p. ej., "80% de los estadounidenses") | Media |
| Agresividad del CTA | CTAs agresivos en páginas de cultura formal (p. ej., "¡COMPRA YA!" en ja-JP) | Baja |
| Referencias legales | Leyes de la jurisdicción equivocada citadas (p. ej., CCPA en de-DE en lugar de DSGVO) | Alta |
| Discrepancia de moneda/unidades | Precios en USD en páginas EUR, unidades imperiales en páginas métricas | Alta |
| Elementos sin traducir | Texto en inglés que permanece en la navegación, botones, alt text, schema | Media |

## Cálculo de la Puntuación de Paridad

Puntuación sobre 100:
- Paridad de existencia de página: 30 puntos
- Paridad de elementos SEO (título, meta, schema): 30 puntos
- Paridad de estructura de contenido (secciones, imágenes, FAQ): 25 puntos
- Paridad de frescura: 15 puntos

Interpretación:
- 90-100: paridad excelente en todas las versiones de idioma
- 70-89: buena paridad con carencias menores a resolver
- 50-69: problemas de paridad significativos que afectan a algunas versiones de idioma
- Menos de 50: fallos de paridad importantes que requieren atención inmediata

## Formato de Salida

Preséntalo como una tabla matriz:
```
| Página | EN | DE | FR | ES | JA | Puntuación de Paridad |
|--------|----|----|----|----|----| -------------------------|
| /sobre-nosotros | ✅ | ✅ | ✅ | ❌ | ✅ | 80/100 |
| /precios | ✅ | ✅ | ⚠️ | ❌ | ❌ | 45/100 |
```
