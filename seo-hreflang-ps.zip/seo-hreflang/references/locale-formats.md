# Referencia de Formatos de Locale para SEO Internacional

Carga esta referencia al validar la paridad de contenido o generar contenido localizado.
Los formatos incorrectos (p. ej., formato de fecha de EE.UU. en una página alemana) indican
mala localización y reducen la confianza del usuario.

## Formatos de Número

| Locale | Miles | Decimal | Ejemplo |
|--------|-------|---------|---------|
| en-US | , | . | 1,234.56 |
| en-GB | , | . | 1,234.56 |
| de-DE | . | , | 1.234,56 |
| de-AT | . | , | 1.234,56 |
| de-CH | ' | . | 1'234.56 |
| fr-FR | (espacio) | , | 1 234,56 |
| fr-CA | (espacio) | , | 1 234,56 |
| es-ES | . | , | 1.234,56 |
| es-MX | , | . | 1,234.56 |
| ja-JP | , | . | 1,234 |
| pt-BR | . | , | 1.234,56 |
| it-IT | . | , | 1.234,56 |
| nl-NL | . | , | 1.234,56 |
| ko-KR | , | . | 1,234 |
| zh-CN | , | . | 1,234.56 |

## Formatos de Fecha

| Locale | Formato | Ejemplo |
|--------|---------|---------|
| en-US | MM/DD/AAAA | 04/14/2026 |
| en-GB | DD/MM/AAAA | 14/04/2026 |
| de-DE | DD.MM.AAAA | 14.04.2026 |
| fr-FR | DD/MM/AAAA | 14/04/2026 |
| es-ES | DD/MM/AAAA | 14/04/2026 |
| ja-JP | AAAA/MM/DD o AAAA年MM月DD日 | 2026/04/14 |
| pt-BR | DD/MM/AAAA | 14/04/2026 |
| ko-KR | AAAA.MM.DD | 2026.04.14 |
| zh-CN | AAAA年MM月DD日 | 2026年04月14日 |

## Formatos de Moneda

| Locale | Símbolo | Colocación | Ejemplo |
|--------|---------|------------|---------|
| en-US | $ | Antes | $1,234.56 |
| en-GB | £ | Antes | £1,234.56 |
| de-DE | € | Después (espacio) | 1.234,56 € |
| fr-FR | € | Después (espacio) | 1 234,56 € |
| es-ES | € | Después (espacio) | 1.234,56 € |
| ja-JP | ¥ | Antes | ¥1,234 |
| pt-BR | R$ | Antes | R$ 1.234,56 |
| ko-KR | ₩ | Antes | ₩1,234 |
| zh-CN | ¥ | Antes | ¥1,234.56 |
| de-CH | CHF | Antes | CHF 1'234.56 |

## Formatos de Dirección

| Región | Orden | Ejemplo |
|--------|-------|---------|
| US/CA | Calle, Ciudad, Estado CP | 123 Main St, Austin, TX 78701 |
| UK | Calle, Ciudad, Código Postal | 10 Downing St, London, SW1A 2AA |
| DE/AT | Calle Nº, CP Ciudad | Hauptstr. 1, 10115 Berlin |
| FR | Calle, Código Postal Ciudad | 1 Rue de Rivoli, 75001 Paris |
| JP | Postal Ciudad Distrito Calle | 〒100-0001 東京都千代田区千代田1-1 |
| ES | Calle Nº, CP Ciudad (Provincia) | Calle Mayor 1, 28013 Madrid |

## Formatos de Teléfono

| Región | Formato | Ejemplo |
|--------|---------|---------|
| US | +1 (XXX) XXX-XXXX | +1 (512) 555-0123 |
| UK | +44 XXXX XXXXXX | +44 2071 234567 |
| DE | +49 XXX XXXXXXX | +49 30 12345678 |
| FR | +33 X XX XX XX XX | +33 1 23 45 67 89 |
| JP | +81 X-XXXX-XXXX | +81 3-1234-5678 |
| ES | +34 XXX XX XX XX | +34 912 34 56 78 |

## Ratios de Expansión de Texto (vs. Inglés)

| Idioma | Expansión | Impacto |
|--------|-----------|---------|
| Alemán | +25-35% | Titulares, botones y etiquetas de navegación más largos |
| Francés | +15-25% | Expansión moderada |
| Español | +15-25% | Expansión moderada |
| Italiano | +15-25% | Expansión moderada |
| Portugués | +15-25% | Expansión moderada |
| Neerlandés | +10-20% | Expansión ligera |
| Japonés | -10-25% | Contracción (más compacto) |
| Coreano | -10-20% | Contracción |
| Chino | -20-30% | Contracción significativa |

## Reglas de Validación

Al comprobar la consistencia de formato de locale:
1. Rastrea la página en busca de patrones numéricos (precios, estadísticas, medidas)
2. Compáralos con el formato esperado para el idioma declarado de la página
3. Marca números en formato de EE.UU. en páginas no estadounidenses (p. ej., "$1,234.56" en una página de-DE)
4. Comprueba los formatos de fecha en posts de blog, avisos de copyright, timestamps de actualización
5. Verifica que los símbolos de moneda coinciden con el mercado objetivo
6. Comprueba que los números de teléfono usan formato internacional con el código de país correcto
