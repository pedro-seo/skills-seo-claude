---
name: seo-dataforseo
description: >
  Datos SEO en vivo vía el servidor MCP de DataForSEO. Análisis de SERP (Google, Bing, Yahoo,
  YouTube, Google Images), investigación de keywords (volumen, dificultad, intención, tendencias),
  perfiles de backlinks, análisis on-page (Lighthouse, parsing de contenido), análisis de
  competidores, análisis de contenido, fichas de negocio, visibilidad en IA (scraper de ChatGPT,
  seguimiento de menciones LLM) y analítica de dominio. Requiere la extensión DataForSEO
  instalada. Úsala cuando el usuario diga "dataforseo", "SERP en vivo", "volumen de keywords",
  "datos de backlinks", "datos de competidores", "comprobación de visibilidad en IA", "menciones LLM",
  "SERP de imágenes", "google images", "rankings de imágenes" o "datos reales de búsqueda".
user-invocable: true
argument-hint: "[comando] [consulta]"
license: MIT
compatibility: "Requiere el servidor MCP de DataForSEO"
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# DataForSEO: Datos SEO en Vivo (Extensión)

Datos de búsqueda en vivo vía el servidor MCP de DataForSEO. Proporciona resultados de SERP
en tiempo real (orgánico + imágenes), métricas de keywords, perfiles de backlinks, análisis
on-page, análisis de contenido, fichas de negocio, comprobación de visibilidad en IA y
seguimiento de menciones LLM en 10 módulos de API con más de 79 herramientas MCP.

## Requisitos Previos

Esta skill requiere que la extensión DataForSEO esté instalada:
```bash
./extensions/dataforseo/install.sh
```

**Comprobar disponibilidad:** antes de usar cualquier herramienta de DataForSEO, verifica que
el servidor MCP está conectado comprobando si `serp_organic_live_advanced` o cualquier otra
herramienta de DataForSEO está disponible. Si las herramientas no están disponibles, informa
al usuario de que la extensión no está instalada y proporciona las instrucciones de instalación.

## Consciencia sobre los Créditos de la API

DataForSEO cobra por cada llamada a la API. Sé eficiente:
- Prioriza los endpoints en bloque frente a múltiples llamadas individuales
- Usa parámetros por defecto (EE.UU., inglés) salvo que el usuario especifique otra cosa
- Guarda mentalmente en caché los resultados dentro de una sesión; no vuelvas a pedir los mismos datos
- Avisa al usuario antes de ejecutar operaciones costosas (rastreos completos de backlinks, listas grandes de keywords)

## Controles de Coste

**Antes de cada llamada a la API MCP de DataForSEO**, ejecuta la estimación de coste:
```
python3 scripts/dataforseo_costs.py check <endpoint> [--count N]
```

- Si `"status": "approved"` → continúa con la llamada a la API
- Si `"status": "needs_approval"` → muestra la estimación de coste al usuario y pide confirmación antes de continuar
- Si `"status": "blocked"` → informa al usuario de que se superaría el límite de presupuesto diario; NO continúes

**Tras completar cada llamada a la API**, registra el coste:
```
python3 scripts/dataforseo_costs.py log <endpoint> <coste_real>
```

**Comandos de usuario para gestión de costes:**
- `/seo dataforseo costs today` → muestra el desglose del gasto de hoy
- `/seo dataforseo costs summary` → muestra el historial de gasto de los últimos 7 días
- `/seo dataforseo costs config --mode threshold --threshold 0.50` → configura el modo de aprobación

Carga `references/cost-tiers.md` para ver la tabla completa de precios, los presets de presupuesto y los consejos para reducir costes.

## Referencia Rápida

| Comando | Qué hace |
|---------|----------|
| `/seo dataforseo serp <keyword>` | Resultados orgánicos de SERP de Google |
| `/seo dataforseo serp-images <keyword>` | Resultados de SERP de Google Images |
| `/seo dataforseo serp-youtube <keyword>` | Resultados de búsqueda de YouTube |
| `/seo dataforseo youtube <video_id>` | Análisis profundo de un vídeo de YouTube |
| `/seo dataforseo keywords <seed>` | Ideas y sugerencias de keywords |
| `/seo dataforseo volume <keywords>` | Volumen de búsqueda de keywords |
| `/seo dataforseo difficulty <keywords>` | Puntuaciones de dificultad de keywords |
| `/seo dataforseo intent <keywords>` | Clasificación de intención de búsqueda |
| `/seo dataforseo trends <keyword>` | Datos de Google Trends |
| `/seo dataforseo backlinks <domain>` | Perfil completo de backlinks |
| `/seo dataforseo competitors <domain>` | Análisis de dominios competidores |
| `/seo dataforseo ranked <domain>` | Keywords posicionadas de un dominio |
| `/seo dataforseo intersection <domains>` | Solapamiento de keywords/backlinks |
| `/seo dataforseo traffic <domains>` | Estimación de tráfico en bloque |
| `/seo dataforseo subdomains <domain>` | Subdominios con datos de ranking |
| `/seo dataforseo top-searches <domain>` | Consultas más populares que mencionan el dominio |
| `/seo dataforseo onpage <url>` | Análisis on-page (Lighthouse + parsing) |
| `/seo dataforseo tech <domain>` | Detección de stack tecnológico |
| `/seo dataforseo whois <domain>` | Datos de registro WHOIS |
| `/seo dataforseo content <keyword/url>` | Análisis de contenido y tendencias |
| `/seo dataforseo listings <keyword>` | Búsqueda de fichas de negocio |
| `/seo dataforseo ai-scrape <query>` | Scraper web de ChatGPT para GEO |
| `/seo dataforseo ai-mentions <keyword>` | Seguimiento de menciones LLM para GEO |

---

## Análisis de SERP

### `/seo dataforseo serp <keyword>`

Obtiene resultados orgánicos en vivo de la búsqueda de Google.

**Herramientas MCP:** `serp_organic_live_advanced`

**Parámetros por defecto:** location_code=2840 (EE.UU.), language_code=en, device=desktop, depth=100

**También soporta:** la herramienta `serp_organic_live_advanced` soporta Google, Bing y Yahoo vía el parámetro `se`. Especifica "bing" o "yahoo" para cambiar de motor de búsqueda.

**Salida:** ranking, URL, título, descripción, dominio, featured snippets, referencias de AI overview, People Also Ask.

### `/seo dataforseo serp-youtube <keyword>`

Obtiene resultados de búsqueda de YouTube. Valioso para GEO. Las menciones en YouTube son las que más correlacionan con las citaciones de IA.

**Herramientas MCP:** `serp_youtube_organic_live_advanced`

**Salida:** título del vídeo, canal, visitas, fecha de subida, descripción, URL.

### `/seo dataforseo youtube <video_id>`

Análisis profundo de un vídeo específico de YouTube: información, comentarios y subtítulos. Las menciones en YouTube tienen la correlación más fuerte (0,737) con la visibilidad en IA, lo que las hace críticas para el análisis GEO.

**Herramientas MCP:** `serp_youtube_video_info_live_advanced`, `serp_youtube_video_comments_live_advanced`, `serp_youtube_video_subtitles_live_advanced`

**Parámetros:** video_id (el ID del vídeo de YouTube, p. ej., "dQw4w9WgXcQ")

**Salida:** metadatos del vídeo (título, canal, visitas, likes, descripción), comentarios principales con engagement, texto de subtítulos/transcripción.

### `/seo dataforseo serp-images <keyword>`

Obtiene resultados en vivo de la búsqueda de Google Images. Descubre qué imágenes posicionan
para una keyword, qué dominios dominan los resultados de imagen e identifica oportunidades de contenido visual.

**Herramientas MCP:** `serp_google_images_live_advanced`

**Parámetros por defecto:** location_code=2840 (EE.UU.), language_code=en, device=desktop, depth=100

**Parámetros:** keyword (obligatorio), depth (opcional, máx. 700, facturado por incrementos de 100 resultados), search_param (opcional, p. ej. "site:ejemplo.com")

**Aviso de coste:** usar operadores `site:` o `filetype:` supone **5 veces más coste de API**. Avisa al usuario antes de ejecutar consultas filtradas.

**Salida:** posición, título, alt text, URL de la página de origen, URL directa de la imagen, dominio, URL codificada.

**Análisis a proporcionar:**
- Dominancia de dominio: qué sitios poseen más posiciones de imagen (top 10 dominios por recuento)
- Patrones de alt text: patrones comunes de título/alt text en las imágenes mejor posicionadas
- Distribución de formato: WebP vs JPEG vs PNG en los primeros resultados (inferido de la extensión de image_url)
- Identificación de oportunidades: keywords donde el usuario tiene rankings orgánicos pero ninguna presencia de imagen

---

## Investigación de Keywords

### `/seo dataforseo keywords <seed>`

Genera ideas de keywords, sugerencias y términos relacionados a partir de una keyword semilla.

**Herramientas MCP:** `dataforseo_labs_google_keyword_ideas`, `dataforseo_labs_google_keyword_suggestions`, `dataforseo_labs_google_related_keywords`

**Parámetros por defecto:** location_code=2840 (EE.UU.), language_code=en, limit=50

**Salida:** keyword, volumen de búsqueda, CPC, nivel de competencia, dificultad de keyword, tendencia.

### `/seo dataforseo volume <keywords>`

Obtiene el volumen de búsqueda y métricas para una lista de keywords.

**Herramientas MCP:** `kw_data_google_ads_search_volume`

**Parámetros:** keywords (array, separadas por comas), location_code, language_code

**Salida:** keyword, volumen de búsqueda mensual, CPC, competencia, datos de tendencia mensual.

### `/seo dataforseo difficulty <keywords>`

Calcula las puntuaciones de dificultad de keywords para la competitividad del ranking.

**Herramientas MCP:** `dataforseo_labs_bulk_keyword_difficulty`

**Parámetros:** keywords (array), location_code, language_code

**Salida:** keyword, puntuación de dificultad (0-100), interpretación (Fácil/Media/Difícil/Muy Difícil).

### `/seo dataforseo intent <keywords>`

Clasifica las keywords según la intención de búsqueda del usuario.

**Herramientas MCP:** `dataforseo_labs_search_intent`

**Parámetros:** keywords (array), location_code, language_code

**Salida:** keyword, tipo de intención (informacional, navegacional, comercial, transaccional), puntuación de confianza.

### `/seo dataforseo trends <keyword>`

Analiza las tendencias de keywords a lo largo del tiempo usando datos de Google Trends.

**Herramientas MCP:** `kw_data_google_trends_explore`

**Parámetros:** keywords (array), location_code, date_from, date_to, language_code

**Salida:** keyword, serie temporal, dirección de la tendencia, señales de estacionalidad.

---

## Análisis de Dominio y Competidores

### `/seo dataforseo backlinks <domain>`

Análisis completo del perfil de backlinks.

**Herramientas MCP:** `backlinks_summary`, `backlinks_backlinks`, `backlinks_anchors`, `backlinks_referring_domains`, `backlinks_bulk_spam_score`, `backlinks_timeseries_summary`

**Parámetros por defecto:** limit=100 por subllamada

**Salida:** total de backlinks, dominios referentes, domain rank, spam score, principales anchors, backlinks nuevos/perdidos a lo largo del tiempo, ratio dofollow, principales dominios referentes.

### `/seo dataforseo competitors <domain>`

Identifica dominios competidores y estima el tráfico.

**Herramientas MCP:** `dataforseo_labs_google_competitors_domain`, `dataforseo_labs_google_domain_rank_overview`, `dataforseo_labs_bulk_traffic_estimation`

**Salida:** dominios competidores, % de solapamiento de keywords, tráfico estimado, domain rank, keywords comunes.

### `/seo dataforseo ranked <domain>`

Lista las keywords por las que posiciona un dominio, con posiciones y datos de página.

**Herramientas MCP:** `dataforseo_labs_google_ranked_keywords`, `dataforseo_labs_google_relevant_pages`

**Parámetros por defecto:** limit=100, location_code=2840

**Salida:** keyword, posición, URL, volumen de búsqueda, cuota de tráfico, funciones de SERP.

### `/seo dataforseo intersection <domain1> <domain2> [...]`

Encuentra keywords y fuentes de backlinks compartidas entre 2 y 20 dominios.

**Herramientas MCP:** `dataforseo_labs_google_domain_intersection`, `backlinks_domain_intersection`

**Parámetros:** domains (array de 2-20)

**Salida:** keywords compartidas con posiciones por dominio, fuentes de backlinks compartidas, keywords únicas por dominio.

### `/seo dataforseo traffic <domains>`

Estima el tráfico de búsqueda orgánica para uno o varios dominios.

**Herramientas MCP:** `dataforseo_labs_bulk_traffic_estimation`

**Parámetros:** domains (array)

**Salida:** dominio, tráfico orgánico estimado, coste de tráfico estimado, principales keywords.

### `/seo dataforseo subdomains <domain>`

Enumera los subdominios con sus datos de ranking y estimaciones de tráfico.

**Herramientas MCP:** `dataforseo_labs_google_subdomains`

**Parámetros:** target (dominio), location_code, language_code

**Salida:** subdominio, número de keywords posicionadas, tráfico estimado, coste orgánico.

### `/seo dataforseo top-searches <domain>`

Encuentra las consultas de búsqueda más populares que mencionan un dominio específico en los resultados.

**Herramientas MCP:** `dataforseo_labs_google_top_searches`

**Parámetros:** target (dominio), location_code, language_code

**Salida:** consulta, volumen de búsqueda, posición del dominio, funciones de SERP, cuota de tráfico.

---

## Técnico / On-Page

### `/seo dataforseo onpage <url>`

Ejecuta un análisis on-page que incluye auditoría Lighthouse y parsing de contenido.

**Herramientas MCP:** `on_page_instant_pages`, `on_page_content_parsing`, `on_page_lighthouse`

**Uso:**
- `on_page_instant_pages`: análisis rápido de página (códigos de estado, meta tags, tamaño del contenido, timing de página, enlaces rotos, comprobaciones on-page)
- `on_page_content_parsing`: extrae y analiza el contenido de la página (texto plano, recuento de palabras, estructura)
- `on_page_lighthouse`: auditoría Lighthouse completa (puntuación de rendimiento, accesibilidad, buenas prácticas, SEO, Core Web Vitals)

**Salida:** páginas rastreadas, códigos de estado, meta tags, títulos, tamaño del contenido, tiempos de carga, puntuaciones Lighthouse, enlaces rotos, análisis de recursos.

### `/seo dataforseo tech <domain>`

Detecta las tecnologías usadas en un dominio.

**Herramientas MCP:** `domain_analytics_technologies_domain_technologies`

**Salida:** nombre de la tecnología, versión, categoría (CMS, analítica, CDN, framework, etc.).

### `/seo dataforseo whois <domain>`

Obtiene los datos de registro WHOIS.

**Herramientas MCP:** `domain_analytics_whois_overview`

**Salida:** registrador, fecha de creación, fecha de expiración, servidores de nombres, información del titular (si es pública).

---

## Contenido y Datos de Negocio

### `/seo dataforseo content <keyword/url>`

Analiza la calidad del contenido, busca contenido por tema y sigue tendencias de frases.

**Herramientas MCP:** `content_analysis_search`, `content_analysis_summary`, `content_analysis_phrase_trends`

**Parámetros:** keyword (para búsqueda/tendencias) o URL (para resumen)

**Salida:** coincidencias de contenido con puntuaciones de calidad, análisis de sentimiento, métricas de legibilidad, datos de tendencia de frases a lo largo del tiempo.

### `/seo dataforseo listings <keyword>`

Busca fichas de negocio para análisis competitivo de SEO local.

**Herramientas MCP:** `business_data_business_listings_search`

**Parámetros:** keyword, location (opcional)

**Salida:** nombre del negocio, descripción, categoría, dirección, teléfono, dominio, valoración, número de reseñas, estado de reclamación.

---

## Visibilidad en IA / GEO

### `/seo dataforseo ai-scrape <query>`

Extrae lo que devuelve la búsqueda web de ChatGPT para una consulta. Comprobación real de visibilidad GEO: descubre qué fuentes cita ChatGPT para tus keywords objetivo.

**Herramientas MCP:** `ai_optimization_chat_gpt_scraper`

**Parámetros:** query, location_code (opcional), language_code (opcional). Usa `ai_optimization_chat_gpt_scraper_locations` para consultar las ubicaciones disponibles.

**Salida:** contenido de la respuesta de ChatGPT, fuentes/URLs citadas, dominios referenciados.

### `/seo dataforseo ai-mentions <keyword>`

Sigue cómo mencionan los LLM a marcas, dominios y temas. Crítico para GEO. Mide la visibilidad real en IA a través de varias plataformas LLM.

**Herramientas MCP:** `ai_opt_llm_ment_search`, `ai_opt_llm_ment_top_domains`, `ai_opt_llm_ment_top_pages`, `ai_opt_llm_ment_agg_metrics`

**Parámetros:** keyword, location_code (opcional), language_code (opcional). Usa `ai_opt_llm_ment_loc_and_lang` para ubicaciones/idiomas disponibles y `ai_optimization_llm_models` para los modelos LLM soportados.

**Flujo de trabajo:**
1. Busca menciones LLM con `ai_opt_llm_ment_search` (encuentra menciones de una marca/keyword en respuestas de LLM)
2. Obtén los dominios más citados con `ai_opt_llm_ment_top_domains` (qué dominios se citan más para este tema)
3. Obtén las páginas más citadas con `ai_opt_llm_ment_top_pages` (qué páginas concretas se citan más)
4. Obtén métricas agregadas con `ai_opt_llm_ment_agg_metrics` (volumen de menciones global, tendencias)

**Salida:** número de menciones LLM, principales dominios citados con frecuencia, principales páginas citadas, tendencias de menciones a lo largo del tiempo, puntuaciones de visibilidad multiplataforma.

**Avanzado:** usa `ai_opt_llm_ment_cross_agg_metrics` para comparación entre modelos (cómo difieren las menciones entre ChatGPT, Claude, Perplexity, etc.).

---

## Herramientas de Utilidad Disponibles

Hay herramientas adicionales de DataForSEO MCP disponibles para uso interno pero sin comandos dedicados. Carga `references/tool-catalog.md` cuando necesites encontrar una herramienta de utilidad específica (búsquedas de ubicación, operaciones en bloque, datos históricos, opciones de filtro).

## Integración Entre Skills

Cuando las herramientas DataForSEO MCP están disponibles, otras skills de esta suite pueden aprovechar los datos en vivo:

- **seo-audit**: activa el agente `seo-dataforseo` para datos reales de SERP, backlinks, on-page y fichas de negocio
- **seo-technical**: usa `on_page_instant_pages` / `on_page_lighthouse` para datos de rastreo reales, `domain_analytics_technologies_domain_technologies` para detección de stack
- **seo-content**: usa `kw_data_google_ads_search_volume`, `dataforseo_labs_bulk_keyword_difficulty`, `dataforseo_labs_search_intent` para métricas reales de keywords, `content_analysis_summary` para calidad de contenido
- **seo-page**: usa `serp_organic_live_advanced` para posiciones reales de SERP, `backlinks_summary` para datos de enlaces
- **seo-images**: usa `serp_google_images_live_advanced` para datos de SERP de imágenes de competidores, cruzados con la auditoría on-page de imágenes
- **seo-geo**: usa `ai_optimization_chat_gpt_scraper` para visibilidad real en ChatGPT, `ai_opt_llm_ment_search` para seguimiento de menciones LLM
- **seo-plan**: usa `dataforseo_labs_google_competitors_domain`, `dataforseo_labs_google_domain_intersection`, `dataforseo_labs_bulk_traffic_estimation` para inteligencia competitiva real

## Manejo de Errores

- **Servidor MCP no conectado**: informa de que la extensión DataForSEO no está instalada o el servidor MCP es inaccesible. Sugiere ejecutar `./extensions/dataforseo/install.sh`
- **Fallo de autenticación de la API**: informa de credenciales inválidas. Sugiere comprobar el login/contraseña de la API de DataForSEO en la configuración MCP
- **Límite de peticiones excedido**: informa del límite alcanzado y sugiere esperar antes de reintentar
- **Sin resultados devueltos**: informa de "sin datos encontrados" para la consulta en lugar de inventar. Sugiere ampliar la consulta o comprobar los códigos de ubicación/idioma
- **Código de ubicación inválido**: informa del error y sugiere usar la herramienta de búsqueda de ubicaciones para encontrar el código correcto

## Formato de Salida

Sigue los patrones de salida existentes de esta skill:
- Usa tablas para datos comparativos
- Prioriza los problemas como Crítico > Alto > Medio > Bajo
- Incluye recomendaciones específicas y accionables
- Muestra las puntuaciones como XX/100 cuando corresponda
- Indica la fuente de datos como "DataForSEO (en vivo)" para distinguirla del análisis estático
