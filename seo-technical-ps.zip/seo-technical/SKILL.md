---
name: seo-technical
description: >
  Auditoría SEO técnica en 9 categorías: rastreabilidad, indexabilidad,
  seguridad, estructura de URLs, móvil, Core Web Vitals, datos estructurados,
  renderizado con JavaScript y protocolo IndexNow. Úsala cuando el usuario
  diga "SEO técnico", "problemas de rastreo", "robots.txt", "Core Web
  Vitals", "velocidad del sitio" o "cabeceras de seguridad".
user-invocable: true
argument-hint: "[url]"
license: MIT
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Auditoría SEO Técnica

## Categorías

### 1. Rastreabilidad
- robots.txt: existe, es válido, no bloquea recursos importantes
- Sitemap XML: existe, referenciado en robots.txt, formato válido
- Etiquetas noindex: intencionadas vs. accidentales
- Profundidad de rastreo: páginas importantes a 3 clics o menos de la home
- Renderizado con JavaScript: comprobar si el contenido crítico requiere ejecución de JS
- Presupuesto de rastreo: para sitios grandes (>10k páginas), la eficiencia importa

#### Gestión de Rastreadores de IA

A fecha de 2025-2026, las empresas de IA rastrean activamente la web para entrenar modelos e impulsar la búsqueda con IA. Gestionar estos rastreadores vía robots.txt es una consideración técnica de SEO crítica.

**Rastreadores de IA conocidos:**

| Rastreador | Empresa | Token de robots.txt | Propósito |
|------------|---------|------------------------|-----------|
| GPTBot | OpenAI | `GPTBot` | Entrenamiento de modelos |
| ChatGPT-User | OpenAI | `ChatGPT-User` | Navegación en tiempo real |
| ClaudeBot | Anthropic | `ClaudeBot` | Entrenamiento de modelos |
| PerplexityBot | Perplexity | `PerplexityBot` | Índice de búsqueda + entrenamiento |
| Bytespider | ByteDance | `Bytespider` | Entrenamiento de modelos |
| Google-Extended | Google | `Google-Extended` | Entrenamiento de Gemini (NO búsqueda) |
| CCBot | Common Crawl | `CCBot` | Dataset abierto |

**Distinciones clave:**
- Bloquear `Google-Extended` impide el uso para entrenar Gemini pero NO afecta a la indexación en Google Search ni a los AI Overviews (esos usan `Googlebot`)
- Bloquear `GPTBot` impide el entrenamiento de OpenAI pero NO impide que ChatGPT cite tu contenido mediante navegación (`ChatGPT-User`)
- ~3-5% de los sitios web ya usan reglas de robots.txt específicas para IA

**Ejemplo de bloqueo selectivo de rastreadores de IA:**
```
# Permitir la indexación en búsqueda, bloquear rastreadores de entrenamiento de IA
User-agent: GPTBot
Disallow: /

User-agent: Google-Extended
Disallow: /

User-agent: Bytespider
Disallow: /

# Permitir todos los demás rastreadores (incluido Googlebot para búsqueda)
User-agent: *
Allow: /
```

**Recomendación:** considera tu estrategia de visibilidad en IA antes de bloquear. Ser citado por sistemas de IA impulsa el reconocimiento de marca y el tráfico de referencia. Consulta la skill `seo-geo` para la optimización completa de visibilidad en IA.

### 2. Indexabilidad
- Etiquetas canonical: autorreferenciadas, sin conflictos con noindex
- Contenido duplicado: casi-duplicados, URLs con parámetros, www vs. sin www
- Contenido escaso: páginas por debajo del recuento mínimo de palabras según su tipo
- Paginación: patrón rel=next/prev o load-more
- Hreflang: correcto para sitios multi-idioma/multi-región
- Sobrecarga de índice: páginas innecesarias que consumen presupuesto de rastreo

### 3. Seguridad
- HTTPS: forzado, certificado SSL válido, sin contenido mixto
- Cabeceras de seguridad:
  - Content-Security-Policy (CSP)
  - Strict-Transport-Security (HSTS)
  - X-Frame-Options
  - X-Content-Type-Options
  - Referrer-Policy
- Precarga de HSTS: comprobar la inclusión en la lista de precarga para sitios de alta seguridad

### 4. Estructura de URLs
- URLs limpias: descriptivas, con guiones, sin parámetros de consulta para el contenido
- Jerarquía: estructura de carpetas lógica que refleja la arquitectura del sitio
- Redirecciones: sin cadenas (máximo 1 salto), 301 para cambios permanentes
- Longitud de URL: marcar las de más de 100 caracteres
- Barras finales: uso consistente

### 5. Optimización Móvil
- Diseño responsive: meta tag viewport, CSS responsive
- Áreas táctiles: mínimo 48x48px con 8px de espaciado
- Tamaño de fuente: mínimo 16px de base
- Sin scroll horizontal
- Indexación mobile-first: Google indexa la versión móvil. **La indexación mobile-first está completa al 100% desde el 5 de julio de 2024.** Google ahora rastrea e indexa TODOS los sitios web exclusivamente con el user-agent móvil de Googlebot.

### 6. Core Web Vitals
- **LCP** (Largest Contentful Paint): objetivo <2,5s
- **INP** (Interaction to Next Paint): objetivo <200ms
  - INP sustituyó a FID el 12 de marzo de 2024. FID se eliminó por completo de todas las herramientas de Chrome (CrUX API, PageSpeed Insights, Lighthouse) el 9 de septiembre de 2024. NO menciones FID en ningún sitio.
- **CLS** (Cumulative Layout Shift): objetivo <0,1
- La evaluación usa el percentil 75 de datos reales de usuarios
- Usa la API de PageSpeed Insights o datos de CrUX si hay MCP disponible

### 7. Datos Estructurados
- Detección: JSON-LD (preferido), Microdata, RDFa
- Validación contra los tipos soportados por Google
- Ver la skill seo-schema para el análisis completo

### 8. Renderizado con JavaScript
- Comprobar si el contenido es visible en el HTML inicial o requiere JS
- Identificar renderizado del lado del cliente (CSR) vs. del lado del servidor (SSR)
- Marcar frameworks SPA (React, Vue, Angular) que puedan causar problemas de indexación
- Verificar la configuración de renderizado dinámico si aplica

#### SEO de JavaScript: Guía de Canonical e Indexación (Diciembre 2025)

Google actualizó su documentación de SEO de JavaScript en diciembre de 2025 con aclaraciones críticas:

1. **Conflictos de canonical:** si una etiqueta canonical en el HTML en bruto difiere de una inyectada por JavaScript, Google puede usar CUALQUIERA de las dos. Asegúrate de que las etiquetas canonical sean idénticas entre el HTML renderizado por el servidor y la salida renderizada con JS.
2. **noindex con JavaScript:** si el HTML en bruto contiene `<meta name="robots" content="noindex">` pero JavaScript lo elimina, Google PUEDE seguir respetando el noindex del HTML en bruto. Sirve las directivas robots correctas en la respuesta HTML inicial.
3. **Códigos de estado distintos de 200:** Google NO renderiza JavaScript en páginas que devuelven códigos de estado HTTP distintos de 200. Cualquier contenido o meta tag inyectado vía JS en páginas de error será invisible para Googlebot.
4. **Datos estructurados en JavaScript:** el schema de Product, Article y otros datos estructurados inyectados vía JS pueden sufrir un procesamiento retrasado. Para datos estructurados sensibles al tiempo (especialmente el marcado de Product de e-commerce), inclúyelos en el HTML renderizado por el servidor desde el inicio.

**Buena práctica:** sirve los elementos SEO críticos (canonical, meta robots, datos estructurados, título, meta description) en el HTML renderizado por el servidor inicial, en lugar de depender de la inyección vía JavaScript.

### 9. Protocolo IndexNow
- Comprueba si el sitio soporta IndexNow para Bing, Yandex, Naver
- Soportado por motores de búsqueda distintos de Google
- Recomienda su implementación para una indexación más rápida en motores no Google

## Páginas Amigables para Agentes (de cara al futuro)

Los agentes de IA (no solo los resumidores de IA) leen cada vez más los sitios a través de tres
canales: modelos de visión sobre capturas de pantalla, HTML/DOM en bruto, y el **árbol de
accesibilidad** (la señal más limpia). Los criterios de auditoría — HTML semántico (`<button>`
y `<a>` reales, no `<div onclick>`), asociaciones de etiquetas, tamaño de los objetivos
interactivos, estabilidad de layout entre plantillas, corrección de `cursor: pointer` — están en
`references/agent-friendly-pages.md`.

### Comando de auditoría

```bash
# Renderiza con Playwright + captura el árbol de accesibilidad, luego puntúa
python3 scripts/agent_ux_check.py https://ejemplo.com --json
```

El escáner devuelve una puntuación Agent-UX (0-100) más problemas detallados:
- Hallazgos de HTML: botones/anchors reales, widgets `<div onclick>`, landmarks
  semánticos, inputs sin `<label for>`, inputs sin etiquetas ARIA
- Hallazgos del árbol de accesibilidad: nodos totales, nodos interactivos, elementos
  interactivos sin nombre, ratio de `role="generic"`

La instantánea del árbol de accesibilidad usa
`page.accessibility.snapshot(interesting_only=False)` de Playwright. Para capturar el
árbol sin puntuar, usa `python3 scripts/render_page.py <url> --a11y-tree --json`.

Presenta los hallazgos como **oportunidades**, no como fallos. Los estándares (WebMCP,
heurísticas de UX de agentes) están en fase temprana — no condiciones las auditorías a
una puntuación por debajo de 100.

## Salida

### Puntuación Técnica: XX/100

### Desglose por Categoría
| Categoría | Estado | Puntuación |
|-----------|--------|------------|
| Rastreabilidad | pass/warn/fail | XX/100 |
| Indexabilidad | pass/warn/fail | XX/100 |
| Seguridad | pass/warn/fail | XX/100 |
| Estructura de URLs | pass/warn/fail | XX/100 |
| Móvil | pass/warn/fail | XX/100 |
| Core Web Vitals | pass/warn/fail | XX/100 |
| Datos Estructurados | pass/warn/fail | XX/100 |
| Renderizado JS | pass/warn/fail | XX/100 |
| IndexNow | pass/warn/fail | XX/100 |

### Problemas Críticos (corregir de inmediato)
### Prioridad Alta (corregir en 1 semana)
### Prioridad Media (corregir en 1 mes)
### Prioridad Baja (backlog)

## Integración con DataForSEO (Opcional)

Si las herramientas DataForSEO MCP están disponibles, usa `on_page_instant_pages` para el análisis real de páginas (códigos de estado, timing de página, enlaces rotos, comprobaciones on-page), `on_page_lighthouse` para auditorías Lighthouse (puntuaciones de rendimiento, accesibilidad, SEO), y `domain_analytics_technologies_domain_technologies` para la detección de stack tecnológico.

## Integración con la API de Google (Opcional)

Si hay credenciales de la API de Google configuradas, usa `python3 scripts/pagespeed_check.py <url> --json` para datos reales de PSI + campo CrUX (sustituye las estimaciones de CWV solo de laboratorio), `python3 scripts/crux_history.py <url> --json` para tendencias de CWV de 25 semanas, y `python3 scripts/gsc_inspect.py <url> --json` para el estado real de indexación por URL.

## Manejo de Errores

| Escenario | Acción |
|-----------|--------|
| URL inaccesible | Informa del error de conexión con el código de estado. Sugiere verificar la URL, comprobar la resolución DNS y confirmar que el sitio es accesible públicamente. |
| No se encontró robots.txt | Señala que no se detectó ningún robots.txt en el dominio raíz. Recomienda crear uno con las directivas apropiadas. Continúa la auditoría en el resto de categorías. |
| HTTPS no configurado | Márcalo como problema crítico. Informa de si se sirve HTTP sin redirección, si existe contenido mixto, o si el certificado SSL falta/ha expirado. |
| Datos de Core Web Vitals no disponibles | Señala que los datos de CrUX no están disponibles (común en sitios de bajo tráfico). Sugiere usar datos de laboratorio de Lighthouse como proxy y recomienda aumentar el tráfico antes de volver a probar. |
