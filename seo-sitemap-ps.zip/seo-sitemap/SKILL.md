---
name: seo-sitemap
description: >
  Analiza sitemaps XML existentes o genera nuevos con plantillas por sector.
  Valida formato, URLs y estructura. Úsala cuando el usuario diga "sitemap",
  "generar sitemap", "problemas de sitemap" o "sitemap XML".
user-invocable: true
argument-hint: "[url o generate]"
license: MIT
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Análisis y Generación de Sitemap

## Modo 1: Analizar Sitemap Existente

### Comprobaciones de Validación
- Formato XML válido
- Recuento de URLs <50.000 por archivo (límite del protocolo)
- Todas las URLs devuelven HTTP 200
- Las fechas `<lastmod>` son precisas (no todas idénticas)
- Sin etiquetas obsoletas: `<priority>` y `<changefreq>` son ignoradas por Google
- El sitemap está referenciado en robots.txt
- Compara las páginas rastreadas frente al sitemap; marca las páginas faltantes

### Señales de Calidad
- Archivo índice de sitemap si hay más de 50k URLs
- Dividido por tipo de contenido (páginas, posts, imágenes, vídeos)
- Sin URLs no canónicas en el sitemap
- Sin URLs noindex en el sitemap
- Sin URLs redirigidas en el sitemap
- Solo URLs HTTPS (nada de HTTP)

### Problemas Comunes
| Problema | Severidad | Solución |
|----------|-----------|----------|
| >50k URLs en un solo archivo | Crítico | Dividir con un índice de sitemap |
| URLs que no devuelven 200 | Alto | Eliminar o corregir las URLs rotas |
| URLs noindex incluidas | Alto | Eliminar del sitemap |
| URLs redirigidas incluidas | Medio | Actualizar a las URLs finales |
| Todas las lastmod idénticas | Bajo | Usar fechas de modificación reales |
| Se usa priority/changefreq | Info | Se puede eliminar (Google lo ignora) |

## Modo 2: Generar un Sitemap Nuevo

### Proceso
1. Pregunta por el tipo de negocio (o detéctalo automáticamente del sitio existente)
2. Carga la plantilla de sector desde el directorio `../seo-plan/assets/`
3. Planificación interactiva de la estructura con el usuario
4. Aplica los controles de calidad:
   - ⚠️ AVISO a partir de 30+ páginas de ubicación (exigir 60%+ de contenido único)
   - 🛑 PARADA OBLIGATORIA a partir de 50+ páginas de ubicación (requiere justificación)
5. Genera la salida XML válida
6. Divide a partir de 50k URLs con un índice de sitemap
7. Genera la documentación STRUCTURE.md

### Páginas Programáticas Seguras (OK a escala)
✅ Páginas de integración (con documentación de configuración real)
✅ Páginas de plantilla/herramienta (con contenido descargable)
✅ Páginas de glosario (definiciones de 200+ palabras)
✅ Páginas de producto (specs y reseñas únicas)
✅ Páginas de perfil de usuario (contenido generado por el usuario)

### Riesgo de Penalización (evitar a escala)
❌ Páginas de ubicación con solo el nombre de ciudad cambiado
❌ "Mejor [herramienta] para [sector]" sin valor específico del sector
❌ "Alternativa a [competidor]" sin datos de comparación reales
❌ Páginas generadas por IA sin revisión humana ni valor único

## Formato del Sitemap

### Sitemap Estándar
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://ejemplo.com/pagina</loc>
    <lastmod>2026-02-07</lastmod>
  </url>
</urlset>
```

### Índice de Sitemap (para >50k URLs)
```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://ejemplo.com/sitemap-paginas.xml</loc>
    <lastmod>2026-02-07</lastmod>
  </sitemap>
  <sitemap>
    <loc>https://ejemplo.com/sitemap-posts.xml</loc>
    <lastmod>2026-02-07</lastmod>
  </sitemap>
</sitemapindex>
```

## Manejo de Errores

- **URL inaccesible**: informa del código de estado HTTP y sugiere comprobar si el sitio está activo
- **No se encontró sitemap**: comprueba las ubicaciones habituales (/sitemap.xml, /sitemap_index.xml, referencia en robots.txt) antes de informar de "no encontrado"
- **Formato XML inválido**: informa de los errores de parsing específicos con números de línea
- **Rate limiting detectado**: reduce el ritmo e informa de resultados parciales con una nota sobre el tiempo de reintento

## Salida

### Para el Análisis
- `VALIDATION-REPORT.md`: resultados del análisis
- Lista de problemas con severidad
- Recomendaciones

### Para la Generación
- `sitemap.xml` (o archivos divididos con índice)
- `STRUCTURE.md`: documentación de la arquitectura del sitio
- Resumen de recuento de URLs y organización
