---
name: seo-cluster
description: >
  Clustering semántico de temas basado en solapamiento de SERP para planificar
  la arquitectura de contenidos. Agrupa keywords por solapamiento real en el
  SERP de Google (no por similitud de texto), diseña clusters de contenido
  hub-and-spoke con matrices de enlazado interno y genera visualizaciones
  interactivas. Opcionalmente ejecuta la creación de contenido si claude-blog
  está instalado. Úsala cuando el usuario diga "topic cluster", "cluster de
  contenido", "clustering semántico", "pillar page", "hub and spoke",
  "arquitectura de contenido", "agrupación de keywords" o "plan de cluster".
user-invocable: true
argument-hint: "<seed-keyword o url>"
license: MIT
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Clustering Semántico de Temas (v1.9.0)

Clustering de keywords guiado por el solapamiento de SERP para la arquitectura de
contenidos. Agrupa keywords según cómo las posiciona realmente Google (resultados
compartidos en el top 10), no por similitud de texto. Diseña clusters de contenido
hub-and-spoke con matrices de enlazado interno y genera visualizaciones interactivas
del mapa de clusters.

**Scripts:** ubicados en el directorio raíz del plugin `scripts/`.

---

## Referencia Rápida

| Comando | Qué hace |
|---------|----------|
| `/seo cluster plan <seed-keyword>` | Flujo de planificación completo: expandir, agrupar, diseñar arquitectura, visualizar |
| `/seo cluster plan --from strategy` | Importa desde una salida existente de `/seo plan` |
| `/seo cluster execute` | Ejecuta el plan: crea contenido vía claude-blog o genera briefs |
| `/seo cluster map` | Regenera la visualización interactiva del cluster |

---

## Flujo de Planificación

### Paso 1: Expansión de la Keyword Semilla

Expande la keyword semilla en 30-50 variantes usando WebSearch:

1. **Búsquedas relacionadas** — busca la semilla, extrae "búsquedas relacionadas" y "la gente también busca"
2. **People Also Ask (PAA)** — extrae todas las preguntas PAA de los resultados de búsqueda
3. **Modificadores long-tail** — añade modificadores comunes: "mejor", "cómo hacer", "vs", "para principiantes", "herramientas", "ejemplos", "guía", "plantilla", "errores", "checklist"
4. **Minería de preguntas** — genera variantes de quién/qué/cuándo/dónde/por qué/cómo
5. **Modificadores de intención** — añade modificadores comerciales: "precio", "opinión", "alternativa", "comparativa", "gratis", "top"

**Deduplicación:** normaliza las variantes (minúsculas, elimina artículos), elimina duplicados exactos.
Objetivo: 30-50 variantes de keyword únicas. Si son menos de 30, ejecuta una segunda
pasada de expansión usando las principales preguntas PAA como semillas.

### Paso 2: Clustering por Solapamiento de SERP

Este es el diferenciador principal. Carga `references/serp-overlap-methodology.md` para
el algoritmo completo.

**Proceso:**
1. Agrupa las keywords por una estimación inicial de intención (reduce las comparaciones por pares)
2. Para cada par candidato dentro de un grupo, haz WebSearch de ambas keywords
3. Cuenta las URLs compartidas en los 10 primeros resultados orgánicos (ignora anuncios, featured snippets, PAA)
4. Aplica los umbrales:

| Resultados Compartidos | Relación | Acción |
|------------------------|----------|--------|
| 7-10 | Mismo post | Fusionar en una única página objetivo |
| 4-6 | Mismo cluster | Agrupar bajo el mismo spoke cluster |
| 2-3 | Enlazar entre sí | Colocar en clusters adyacentes, añadir enlaces cruzados |
| 0-1 | Separado | Asignar a clusters distintos o excluir |

**Optimización:** con 40 keywords, la comparación completa por pares serían 780 comparaciones. En su lugar:
- Preagrupa por intención (4 grupos de ~10 = 4 x 45 = 180 comparaciones)
- Verifica solo las keywords en el límite entre grupos
- Salta los pares donde ambas son variantes long-tail del mismo término principal (asume mismo cluster)

**Integración con DataForSEO:** si DataForSEO MCP está disponible, usa `serp_organic_live_advanced`
en lugar de WebSearch para los datos de SERP. Ejecuta `python3 scripts/dataforseo_costs.py check serp_organic_live_advanced --count N`
antes de cada lote. Si el resultado es `"status": "needs_approval"`, muestra la estimación de coste y pregunta al usuario.
Si es `"status": "blocked"`, usa WebSearch como alternativa.

### Paso 3: Clasificación de Intención

Clasifica cada keyword en una de estas cuatro categorías de intención:

| Intención | Señales | ¿Se incluye en clusters? |
|-----------|---------|---------------------------|
| Informacional | cómo, qué, por qué, guía, tutorial, aprender | Sí |
| Comercial | mejor, top, opinión, comparativa, vs, alternativa | Sí |
| Transaccional | comprar, precio, descuento, cupón, pedir, registrarse | Sí |
| Navegacional | nombres de marca, nombres de producto específicos, login | No (excluir) |

Elimina las keywords navegacionales del clustering. Marca los casos límite para
revisión manual. Las keywords pueden tener intención mixta (p. ej., "mejor software CRM" es
comercial e informacional a la vez) -- clasifica según la intención dominante.

### Paso 4: Arquitectura Hub-and-Spoke

Carga `references/hub-spoke-architecture.md` para ver las especificaciones completas.

**Diseña la estructura del cluster:**

1. **Selecciona la keyword pilar** — mayor volumen, intención más amplia, mayor solapamiento de SERP con otras keywords
2. **Agrupa los spokes en clusters** — cada cluster es un área de subtema (2-5 clusters por pilar)
3. **Asigna posts a los clusters** — cada cluster recibe 2-4 posts spoke
4. **Selecciona plantillas por post** — según la clasificación de intención:

| Patrón de Intención | Opciones de Plantilla |
|----------------------|------------------------|
| Informacional (amplio) | guía-definitiva |
| Informacional (cómo) | cómo-hacer |
| Informacional (lista) | listado |
| Informacional (concepto) | explicativo |
| Comercial (comparar) | comparativa |
| Comercial (evaluar) | opinión |
| Comercial (rankear) | top-mejores |
| Transaccional | landing-page |

5. **Define objetivos de recuento de palabras:**
   - Página pilar: 2500-4000 palabras
   - Posts spoke: 1200-1800 palabras

6. **Comprobación de canibalización** — ningún post comparte la misma keyword primaria. Si el
   solapamiento de SERP es 7+, fusiona esas keywords en un único post que apunte a ambas.

### Paso 5: Matriz de Enlazado Interno

Diseña la estructura de enlazado bidireccional:

| Tipo de Enlace | Dirección | Requisito |
|-----------------|-----------|-----------|
| Spoke a pilar | spoke -> pilar | Obligatorio (cada spoke) |
| Pilar a spoke | pilar -> spoke | Obligatorio (cada spoke) |
| Spoke a spoke (dentro del cluster) | spoke <-> spoke | 2-3 enlaces por post |
| Entre clusters | spoke -> spoke (otro cluster) | 0-1 enlaces por post |

**Reglas:**
- Cada post debe tener un mínimo de 3 enlaces internos entrantes
- Sin páginas huérfanas (todo post accesible desde el pilar en 2 clics)
- El anchor text debe usar la keyword objetivo o una variante cercana (nunca "haz clic aquí")
- Colocación de enlaces: dentro del contenido del cuerpo, no solo en navegación/sidebar

Genera la matriz de enlaces como una lista de adyacencia JSON:
```json
{
  "links": [
    { "from": "pillar", "to": "cluster-0-post-0", "type": "mandatory", "anchor": "keyword" },
    { "from": "cluster-0-post-0", "to": "pillar", "type": "mandatory", "anchor": "keyword" }
  ]
}
```

### Paso 6: Mapa de Cluster Interactivo

Genera `cluster-map.html` usando la plantilla en `templates/cluster-map.html`.

1. Lee el archivo de plantilla
2. Construye el objeto JSON `CLUSTER_DATA` a partir del plan de cluster:
   ```javascript
   {
     pillar: { title, keyword, volume, template, wordCount, url },
     clusters: [{ name, color, posts: [{ title, keyword, volume, template, wordCount, url, status }] }],
     links: [{ from, to, type }],
     meta: { totalPosts, totalClusters, totalLinks, estimatedWords }
   }
   ```
3. Sustituye el placeholder `CLUSTER_DATA` en la plantilla por el JSON real
4. Escribe el archivo HTML final en el directorio de salida
5. Informa al usuario: "Abre `cluster-map.html` en un navegador para explorar el mapa de cluster interactivo."

---

## Importación de Estrategia

Cuando se invoca con `--from strategy`:

1. Busca la salida más reciente de `/seo plan` en el directorio actual (busca
   archivos que coincidan con `*SEO*Plan*`, `*strategy*`, `*content-strategy*`)
2. Analiza las tablas markdown para extraer: keywords, tipos de página, pilares de contenido, estructuras de URL
3. Valida los datos extraídos: revisa duplicados, keywords faltantes, entradas incompletas
4. Enriquece con datos de SERP: ejecuta el análisis de solapamiento de SERP sobre las keywords extraídas
5. Construye el plan de cluster usando las keywords importadas como conjunto inicial (omite el Paso 1)

Si no se encuentra ningún archivo de estrategia, pregunta al usuario: "No se ha encontrado ningún plan SEO
en el directorio actual. Ejecuta `/seo plan` primero, o proporciona una keyword semilla para un clustering nuevo."

---

## Flujo de Ejecución

Cuando se invoca `/seo cluster execute`:

### Comprueba si claude-blog está disponible

```
Comprobación: ¿existe ~/.claude/skills/blog/SKILL.md?
```

**Si claude-blog ESTÁ instalado:**

1. Carga `references/execution-workflow.md` para el algoritmo completo
2. Lee `cluster-plan.json` del directorio actual
3. Comprueba el estado de reanudación: escanea el directorio de salida en busca de posts ya escritos
4. Ejecuta en orden de prioridad: primero el pilar, luego los spokes por volumen (de mayor a menor)
5. Para cada post, invoca la skill `blog-write` con el contexto del cluster:
   - Rol dentro del cluster (pilar o spoke)
   - Posición en el cluster (índice de cluster, índice de post)
   - Keyword objetivo y keywords secundarias
   - Tipo de plantilla y objetivo de recuento de palabras
   - Enlaces internos a incluir (con anchors)
   - Enlaces que recibirá de futuros posts (marcadores placeholder)
6. Tras escribir cada post, revisa los posts anteriores en busca de placeholders de enlace pendientes
   e inyecta la URL del nuevo post
7. Una vez escritos todos los posts, genera el scorecard del cluster

**Si claude-blog NO está instalado:**

1. Genera briefs de contenido detallados para cada post del plan de cluster
2. Cada brief incluye:
   - Título y meta description
   - Keyword primaria y keywords secundarias
   - Tipo de plantilla y estructura sugerida (esquema H2/H3)
   - Objetivo de recuento de palabras
   - Enlaces internos a incluir (con anchor text)
   - Puntos clave a cubrir
   - Páginas competidoras de las que diferenciarse
3. Escribe los briefs en el directorio `cluster-briefs/` como archivos markdown individuales
4. Informa al usuario: "Instala la skill de blog de Palo Seco para crear el contenido automáticamente. Briefs guardados en `cluster-briefs/`."

---

## Scorecard del Cluster

Informe de calidad post-ejecución. Se ejecuta automáticamente después de `/seo cluster execute` o
bajo demanda mediante el análisis del directorio de salida.

| Métrica | Objetivo | Cómo se Mide |
|---------|----------|----------------|
| Cobertura | 100% | Posts escritos / posts planificados |
| Densidad de Enlaces | 3+ por post | Cuenta de enlaces internos por post |
| Páginas Huérfanas | 0 | Posts con < 1 enlace entrante |
| Canibalización | 0 conflictos | Comprobación de keywords primarias duplicadas |
| Nº de Imágenes | 1+ por post | Posts con al menos una imagen |
| Enlaces al Pilar | 100% | Todos los spokes enlazan al pilar y viceversa |
| Enlaces Cruzados | 80%+ | Enlaces spoke-a-spoke recomendados implementados |
| Vacíos de Contenido | 0 | Posts planificados que se omitieron o quedaron incompletos |

---

## Regeneración del Mapa

Cuando se invoca `/seo cluster map`:

1. Lee `cluster-plan.json` del directorio actual
2. Escanea el directorio de salida y actualiza los estados de los posts (planificado vs escrito)
3. Regenera `cluster-map.html` con los estados actualizados
4. Informa: posts escritos vs planificados, porcentaje de enlaces completados

---

## Archivos de Salida

Todas las salidas se escriben en el directorio de trabajo actual:

| Archivo | Descripción |
|---------|-------------|
| `cluster-plan.json` | Plan de cluster legible por máquina (datos completos) |
| `cluster-plan.md` | Resumen del plan de cluster legible por humanos |
| `cluster-map.html` | Visualización SVG interactiva |
| `cluster-briefs/` | Briefs de contenido (si no hay claude-blog) |
| `cluster-scorecard.md` | Informe de calidad post-ejecución |

---

## Integración con Otras Skills

| Skill | Relación |
|-------|----------|
| `seo-plan` | Fuente de importación: la importación de estrategia lee la salida de seo-plan |
| `seo-content` | Control de calidad: validación E-E-A-T del contenido generado |
| `seo-schema` | Marcado de schema: Article, BreadcrumbList, ItemList para las páginas del cluster |
| `seo-dataforseo` | Fuente de datos: datos de SERP cuando DataForSEO MCP está disponible |
| `seo-google` | Informes: genera un informe PDF del plan de cluster y el scorecard |

Al terminar la planificación o ejecución del cluster, ofrece:
"¿Genero un informe PDF? Usa `/seo google report`"

---

## Manejo de Errores

| Error | Causa | Solución |
|-------|-------|----------|
| "No se proporcionó keyword semilla" | Falta el argumento | Pide al usuario una keyword semilla o URL |
| "Variantes de keyword insuficientes" | La expansión generó < 15 keywords | Ejecuta una segunda pasada de expansión con preguntas PAA |
| "Datos de SERP no disponibles" | Fallan tanto WebSearch como DataForSEO | Reintenta tras 30s; si persiste, usa clustering solo por intención con aviso |
| "No se encontró archivo de estrategia" | `--from strategy` pero no existe ningún plan | Pide al usuario que ejecute `/seo plan` primero |
| "cluster-plan.json no encontrado" | Ejecución sin planificación previa | Pide al usuario que ejecute `/seo cluster plan` primero |
| "claude-blog no instalado" | Se intentó ejecutar sin la skill de blog | Genera briefs de contenido en su lugar; sugiere instalación |
| "Presupuesto de DataForSEO excedido" | La comprobación de coste devolvió "blocked" | Usa WebSearch como alternativa; informa al usuario |
| "Keywords primarias duplicadas" | Canibalización detectada | Fusiona los posts afectados o reasigna keywords |
| "Página huérfana detectada" | Al post le faltan enlaces entrantes | Añade enlaces desde los posts hermanos más cercanos del cluster |
| "Estado de reanudación corrupto" | Discrepancia entre el plan y la salida | Reconstruye el estado escaneando el directorio de salida |

---

## Seguridad

- Todas las URLs se obtienen vía `python3 scripts/render_page.py --mode auto` (protección SSRF consciente de SPA vía `url_safety`)
- No se almacenan ni transmiten credenciales
- Los archivos de salida no contienen PII ni claves API
- Las comprobaciones de coste de DataForSEO se ejecutan antes de cada llamada a la API

## Integración con el Framework FLOW

Para investigación de keywords y análisis de gaps guiados por prompts, usa `/seo flow find [url|topic]` — los 5 prompts de la etapa de búsqueda de FLOW complementan la metodología de clustering por solapamiento de SERP con prompts de descubrimiento estructurados.
