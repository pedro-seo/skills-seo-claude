# Marcador de QA de Traducción Automática (QRG de enero de 2025)

La actualización de las Quality Rater Guidelines de Google del 23 de enero de 2025
añadió texto explícito sobre el **contenido traducido automáticamente sin revisión
humana** como una forma de abuso de contenido a escala (§4.6.5).

> "Usar herramientas automatizadas (IA generativa u otras) como una forma de
> bajo esfuerzo para producir muchas páginas que aportan poco o ningún valor."

El contenido traducido automáticamente está bien **cuando lo revisa y corrige un
hablante humano**. La traducción automática sin revisar — o una edición "ligera"
que aún contiene términos alucinados, concordancia de género/número incorrecta, o
nombres propios sin traducir — se trata como abuso de contenido a escala.

## Señales que la Auditoría de seo-hreflang Debe Sacar a la Luz

| Señal | Severidad | Notas |
|---|---|---|
| Varios alternates de `hreflang` apuntan a URLs cuyo contenido es idéntico salvo por el chrome de cabecera | Crítica | Indica que el cuerpo no se tradujo; solo se envolvió en la plantilla. |
| El atributo `lang="xx"` del `<html>` no coincide con el idioma del cuerpo | Alta | Salida de un pipeline de traducción sin un paso final de QA. |
| `<meta name="description">` autotraducida de más de 160 caracteres (sin recortar) | Media | El traductor superó el límite del snippet — ningún revisor humano lo detectó. |
| El atributo `lang` es `auto` o está completamente ausente | Media | Las páginas que no declaran su idioma confunden a hreflang + rastreadores de IA. |
| Nombres propios o de producto sin traducir salpicados en el cuerpo | Baja (heurística) | Fallo común de traducción automática; difícil de detectar de forma automática. |
| El campo `inLanguage` de Schema.org ausente o incorrecto | Media | Las auditorías multi-idioma deberían cruzar `inLanguage` con el cuerpo. |

## Qué NO Debería Marcar la Auditoría

- Sitios que tienen algunas páginas de traducción automática claramente etiquetadas como tal (un
  patrón de fallback de traducción humana). Las QRG de Google permiten explícitamente
  la traducción automática *cuando está etiquetada honestamente y con un alcance claro*.
- Cadenas de UI traducidas automáticamente — eso es i18n, no "contenido".
- Contenido con `lang="auto"` si la auditoría no puede obtener una señal de fallback
  (sé conservador; no afirmes lo que no se puede verificar).

## Delegación Entre Skills

- Para la validación de hreflang por página, permanece dentro de `seo-hreflang`.
- Para una puntuación más amplia de contenido a escala (entropía de páginas traducidas,
  detección de patrones de IA en el cuerpo), delega en `seo-content` vía
  `python3 scripts/content_quality.py`.
- Para detectar "si esto está traducido por el propio widget de auto-traducción de Google",
  busca el iframe `.goog-te-banner-frame`; los widgets de auto-traducción están
  explícitamente exentos del abuso de contenido a escala por traducción automática,
  pero de todas formas producen mala citabilidad de pasajes.

## Fuentes Primarias

- QRG de enero de 2025 §4.6.5: https://services.google.com/fh/files/misc/hsw-sqrg.pdf
- John Mueller sobre traducción automática (varios episodios de SOTR, 2024-2025): la
  traducción automática está bien cuando la revisa un humano; la traducción automática
  masiva sin revisión es abuso.

Última verificación: 17-05-2026.
