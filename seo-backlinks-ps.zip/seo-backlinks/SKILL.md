---
name: seo-backlinks
description: "Análisis de perfil de backlinks: dominios referentes, distribución de anchor text, detección de enlaces tóxicos, análisis de gap con competidores. Funciona con APIs gratuitas (Moz, Bing Webmaster, Common Crawl) y la extensión DataForSEO. Úsala cuando el usuario diga backlinks, perfil de enlaces, dominios referentes, anchor text, enlaces tóxicos, link gap, link building o auditoría de backlinks."
user-invocable: true
argument-hint: "<url>"
license: MIT
compatibility: "Gratis: Common Crawl + verificación siempre disponibles. Opcional: Moz API, Bing Webmaster (registro gratuito). Premium: extensión DataForSEO."
metadata:
  author: Palo Seco S.L.
  version: "2.2.0"
  category: seo
---

# Análisis de Perfil de Backlinks

## Detección de Fuentes

Antes del análisis, detecta las fuentes de datos disponibles:

1. **DataForSEO MCP** (premium): comprueba si la herramienta `dataforseo_backlinks_summary` está disponible
2. **Moz API** (registro gratuito): `python3 scripts/backlinks_auth.py --check moz --json`
3. **Bing Webmaster** (registro gratuito): `python3 scripts/backlinks_auth.py --check bing --json`
4. **Common Crawl** (siempre disponible): grafo a nivel de dominio con PageRank
5. **Crawler de Verificación** (siempre disponible): comprueba si los backlinks conocidos siguen existiendo

Ejecuta `python3 scripts/backlinks_auth.py --check --json` para detectar todas las fuentes a la vez.

Si no hay ninguna fuente configurada más allá del nivel siempre disponible:
- Genera igualmente un informe usando las métricas de dominio de Common Crawl
- Sugiere: "Ejecuta `/seo backlinks setup` para añadir claves API gratuitas de Moz y Bing y obtener datos más completos"

## Referencia Rápida

| Comando | Propósito |
|---------|-----------|
| `/seo backlinks <url>` | Análisis completo del perfil de backlinks (usa todas las fuentes disponibles) |
| `/seo backlinks gap <url1> <url2>` | Análisis de gap de backlinks con la competencia |
| `/seo backlinks toxic <url>` | Detección de enlaces tóxicos y recomendaciones de disavow |
| `/seo backlinks new <url>` | Backlinks nuevos y perdidos (solo DataForSEO) |
| `/seo backlinks verify <url> --links <file>` | Verifica que los backlinks conocidos sigan existiendo |
| `/seo backlinks setup` | Muestra las instrucciones de configuración de las APIs gratuitas de backlinks |

## Marco de Análisis

Genera las 7 secciones siguientes. Cada sección lista las fuentes de datos en orden de preferencia.

### 1. Visión General del Perfil

**DataForSEO:** `dataforseo_backlinks_summary` → total de backlinks, dominios referentes, domain rank, ratio follow, tendencia.

**Moz API:** `python3 scripts/moz_api.py metrics <url> --json` → Domain Authority, Page Authority, Spam Score, dominios raíz enlazantes, enlaces externos.

**Common Crawl:** `python3 scripts/commoncrawl_graph.py <domain> --json` → grado de entrada (nº de dominios referentes), PageRank, centralidad armónica.

**Puntuación:**

| Métrica | Bien | Aviso | Crítico |
|---------|------|-------|---------|
| Dominios referentes | >100 | 20-100 | <20 |
| Ratio follow | >60% | 40-60% | <40% |
| Diversidad de dominios | Ningún dominio >5% | 1 dominio >10% | 1 dominio >25% |
| Tendencia | Creciente o estable | Declive lento | Declive rápido (>20%/trimestre) |

### 2. Distribución de Anchor Text

**DataForSEO:** `dataforseo_backlinks_anchors`

**Moz API:** `python3 scripts/moz_api.py anchors <url> --json`

**Bing Webmaster:** `python3 scripts/bing_webmaster.py links <url> --json` (extrae el anchor text de los detalles del enlace)

**Rangos saludables de referencia:**

| Tipo de Anchor | Rango Objetivo | Señal de Sobreoptimización |
|-----------------|-----------------|------------------------------|
| De marca (nombre de empresa/dominio) | 30-50% | <15% |
| URL / enlace desnudo | 15-25% | N/A |
| Genérico ("haz clic aquí", "saber más") | 10-20% | N/A |
| Keyword exacta | 3-10% | >15% |
| Keyword parcial | 5-15% | >25% |
| Long-tail / natural | 5-15% | N/A |

Marca como alerta si los anchors de keyword exacta superan el 15% — es una señal de riesgo de Google Penguin.

### 3. Calidad de los Dominios Referentes

**DataForSEO:** `dataforseo_backlinks_referring_domains`

**Moz API:** `python3 scripts/moz_api.py domains <url> --json` → dominios con puntuaciones DA

**Common Crawl:** `python3 scripts/commoncrawl_graph.py <domain> --json` → principales dominios referentes (a nivel de dominio, sin puntuaciones de autoridad)

Analiza:
- **Distribución de TLD**: .edu, .gov, .org = alta autoridad. Exceso de .xyz, .info = baja calidad
- **Distribución por país**: debe coincidir con el mercado objetivo. Más del 80% de países irrelevantes = señal de PBN
- **Distribución del domain rank**: los perfiles saludables tienen enlaces de todos los niveles de autoridad
- **Follow/nofollow por dominio**: los sitios que solo usan nofollow tienen valor SEO limitado

### 4. Detección de Enlaces Tóxicos

**DataForSEO:** `dataforseo_backlinks_bulk_spam_score` + patrones tóxicos de la referencia

**Moz API:** Spam Score de `python3 scripts/moz_api.py metrics <url> --json` (escala 1-17%, >11% = riesgo alto)

**Crawler de Verificación:** `python3 scripts/verify_backlinks.py --target <url> --links <file> --json` (verifica que los enlaces sospechosos sigan existiendo)

**Indicadores de alto riesgo (marcar de inmediato):**
- Enlaces de dominios PBN (Private Blog Network) conocidos
- Patrones de anchor text no naturales (100% keyword exacta desde un dominio)
- Enlaces de dominios penalizados o desindexados
- Envíos masivos a directorios (50+ enlaces desde directorios)
- Granjas de enlaces (sitios con más de 10.000 enlaces salientes por página)
- Patrones de enlaces de pago (enlaces en footer/sidebar en todas las páginas de un dominio)

**Indicadores de riesgo medio (revisar manualmente):**
- Enlaces de nichos no relacionados
- Patrones de enlaces recíprocos
- Enlaces desde páginas de contenido escaso (<100 palabras)
- Exceso de enlaces desde un solo dominio (>50 backlinks desde 1 dominio)

Carga `references/backlink-quality.md` para ver los 30 patrones tóxicos completos y los criterios de disavow.

### 5. Páginas Principales por Backlinks

**DataForSEO:** `dataforseo_backlinks_backlinks` con target type "page"

**Moz API:** `python3 scripts/moz_api.py pages <domain> --json`

Identifica:
- Qué páginas atraen más backlinks
- Páginas con enlaces de alta autoridad (imanes de enlaces)
- Páginas sin ningún backlink (oportunidades de enlazado interno)
- Páginas 404 con backlinks (oportunidades de redirección para recuperar link equity)

### 6. Análisis de Gap con la Competencia

**DataForSEO:** `dataforseo_backlinks_referring_domains` para ambos dominios, luego compara

**Bing Webmaster (única con esto):** `python3 scripts/bing_webmaster.py compare <url1> <url2> --json` — la única herramienta gratuita con comparación de competidores integrada

**Moz API:** compara DA/PA entre dominios con `python3 scripts/moz_api.py metrics <url> --json` para cada uno

Resultado:
- Dominios que enlazan al competidor pero NO al objetivo = oportunidades de link building
- Dominios que enlazan a ambos = valida relaciones existentes
- Dominios que solo enlazan al objetivo = ventaja competitiva
- Top 20 oportunidades de link building con domain authority

### 7. Backlinks Nuevos y Perdidos

**Solo DataForSEO:** `dataforseo_backlinks_backlinks` con filtros de fecha para cambios de 30/60/90 días

**Crawler de Verificación:** para enlaces conocidos, verifica el estado actual con `python3 scripts/verify_backlinks.py`

**Nota:** las fuentes gratuitas no pueden rastrear enlaces nuevos/perdidos a lo largo del tiempo. Si se solicita esta sección sin DataForSEO, informa al usuario: "El seguimiento de velocidad de enlaces requiere la extensión DataForSEO. Las fuentes gratuitas solo ofrecen instantáneas puntuales."

**Señales de alerta:**
- Pico repentino de enlaces nuevos (posible ataque de SEO negativo)
- Pérdida repentina de muchos enlaces (penalización del sitio o eliminación de contenido)
- Velocidad decreciente durante 3+ meses (el contenido no atrae enlaces)

## Puntuación de Salud de Backlinks

Calcula una puntuación de 0 a 100. Al combinar fuentes, aplica ponderación por confianza:

| Factor | Peso | Fuentes (orden de preferencia) | Confianza |
|--------|------|----------------------------------|-----------|
| Nº de dominios referentes | 20% | DataForSEO > Moz > grado de entrada CC | 1.0 / 0.85 / 0.50 |
| Distribución de calidad de dominios | 20% | DataForSEO > distribución DA de Moz | 1.0 / 0.85 |
| Naturalidad del anchor text | 15% | DataForSEO > Moz > anchors de Bing | 1.0 / 0.85 / 0.70 |
| Ratio de enlaces tóxicos | 20% | DataForSEO > spam score de Moz | 1.0 / 0.85 |
| Tendencia de velocidad de enlaces | 10% | Solo DataForSEO | 1.0 |
| Ratio follow/nofollow | 5% | DataForSEO > detalles de Bing | 1.0 / 0.70 |
| Relevancia geográfica | 10% | DataForSEO > país en Bing | 1.0 / 0.70 |

**Umbral de suficiencia de datos:** cuenta cuántos de los 7 factores tienen al menos una fuente de datos disponible.
- **4+ factores con datos:** genera una puntuación numérica de 0-100 (redistribuye los pesos que falten proporcionalmente)
- **Menos de 4 factores:** NO generes una puntuación numérica. Muestra en su lugar:
  ```
  Puntuación de Salud de Backlinks: DATOS INSUFICIENTES (X/7 factores puntuados)
  ```
  Muestra las puntuaciones individuales de los factores que SÍ están disponibles con su fuente y confianza.
  Recomienda: "Configura la API de Moz (gratis) para obtener un perfil puntuable. Ejecuta `/seo backlinks setup`"

Cuando solo esté disponible CC, limita la puntuación máxima a 70/100.
Una puntuación numérica con menos de 4 fuentes de datos es **engañosa** — sugiere mala salud cuando
en realidad simplemente falta información.

## Formato de Salida

### Puntuación de Salud de Backlinks: XX/100 (o DATOS INSUFICIENTES)

| Sección | Estado | Puntuación | Fuente de Datos |
|---------|--------|------------|------------------|
| Visión General del Perfil | pass/warn/fail | XX/100 | Moz (0.85) |
| Distribución de Anchors | pass/warn/fail | XX/100 | Moz (0.85) |
| Calidad de Dominios Referentes | pass/warn/fail | XX/100 | CC (0.50) |
| Enlaces Tóxicos | pass/warn/fail | XX/100 | Moz Spam (0.85) |
| Páginas Principales | info | N/A | Moz (0.85) |
| Velocidad de Enlaces | pass/warn/fail | XX/100 | Solo DataForSEO |

### Problemas Críticos (solucionar de inmediato)
### Prioridad Alta (solucionar en 1 mes)
### Prioridad Media (mejora continua)
### Oportunidades de Link Building (top 10)

## Manejo de Errores

| Error | Causa | Solución |
|-------|-------|----------|
| Ninguna fuente configurada | Sin claves API, sin DataForSEO | Ejecuta `/seo backlinks setup` |
| Límite de tasa de Moz | Plan gratuito: 1 petición/10s | Espera 10 segundos y reintenta. Ya integrado en el script. |
| Sitio de Bing no verificado | El sitio no está verificado en Bing | Verifícalo en https://www.bing.com/webmasters |
| Timeout de descarga de CC | Grafo grande, conexión lenta | Usa el flag `--timeout 180` |
| DataForSEO no disponible | Extensión no instalada | Ejecuta `./extensions/dataforseo/install.sh` |
| No se han devuelto datos de backlinks | Dominio muy nuevo o muy pequeño | Nota: los sitios pequeños pueden tener <10 backlinks |

**Cascada de fallback:**
1. ¿DataForSEO disponible? → Úsalo como fuente principal (confianza: 1.0)
2. ¿Moz configurado? → Úsalo para DA/PA/spam/anchors (confianza: 0.85)
3. ¿Bing configurado? → Úsalo para enlaces/comparación de competidores (confianza: 0.70)
4. Siempre: Common Crawl para métricas a nivel de dominio (confianza: 0.50)
5. Siempre: crawler de verificación para comprobar enlaces conocidos (confianza: 0.95)
6. ¿Nada funciona? → "Ejecuta `/seo backlinks setup` para configurar las APIs gratuitas"

## Revisión Previa a la Entrega (OBLIGATORIA)

Antes de presentar cualquier análisis de backlinks al usuario, ejecuta esta checklist internamente.
No te saltes este paso. Corrige cualquier problema encontrado antes de mostrar el informe.

### Verifica Cada Afirmación
- [ ] **Afirmaciones sobre schema**: ¿parse_html ha devuelto `@type` para cada bloque? Si falta algún `@type`,
      revísalo — puede que use el wrapper `@graph` (JSON-LD válido, no mal formado).
- [ ] **Hallazgos "link_removed"**: ¿La página está renderizada con JS? Si es `unverifiable_js`, indícalo — nunca
      reportes una página renderizada con JS como "enlace eliminado" (sería un falso negativo).
- [ ] **Hallazgos de H1**: ¿Algún H1 está en la lista `h1_suspicious`? Si es así, indica que probablemente
      sean contadores/estadísticas, no encabezados semánticos.
- [ ] **Enlaces recíprocos**: si el sitio A enlaza al sitio B Y B enlaza de vuelta a A, márcalo como
      patrón de enlace recíproco. Compara los enlaces salientes con las fuentes entrantes verificadas.
- [ ] **Puntuación de salud**: ¿Hay 4+ de los 7 factores puntuados? Si no, informa DATOS INSUFICIENTES — nunca
      muestres una puntuación numérica engañosa.

### Verifica las Etiquetas de Fuente de Datos
- [ ] Cada métrica del informe tiene una etiqueta de fuente (p. ej., "Parseado (0.95)", "CC (0.50)")
- [ ] Cada resultado "no encontrado" distingue entre "no rastreado" vs "por debajo del umbral" vs "error"
- [ ] Las páginas de redes sociales se marcan como `unverifiable_js` (no como `link_removed`)

### Verificación Cruzada de Consistencia
- [ ] La detección de plataforma coincide con las señales reales (comprobar wp-content, CDN de Shopify, etc.)
- [ ] El número de dominios referentes del resumen coincide con la lista real de enlaces verificados
- [ ] Ninguna afirmación se presenta sin una fuente de datos que la respalde

Si falla CUALQUIER comprobación, corrige el hallazgo antes de presentarlo. Nunca presentes datos inferidos como hechos.

## Post-Análisis

Después de completar cualquier análisis de backlinks, ofrece siempre:
"¿Genero un informe PDF profesional? Usa `/seo google report`"

## Documentación de Referencia

Carga bajo demanda (NO cargar al inicio):
- `skills/seo/references/backlink-quality.md` -- Patrones tóxicos detallados y metodología de puntuación (referencia compartida, cargar al analizar enlaces tóxicos o spam scores)
- `skills/seo/references/free-backlink-sources.md` -- Comparativa de fuentes, ponderación por confianza, guías de configuración (referencia compartida, cargar al configurar APIs gratuitas de backlinks)
