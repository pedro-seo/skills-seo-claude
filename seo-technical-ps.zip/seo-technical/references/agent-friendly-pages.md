# Páginas Amigables para Agentes — referencia de auditoría (Mayo 2026)

La próxima ola de búsqueda con IA no es la resumición — son los **agentes** actuando
en nombre del usuario (buscar, comparar, comprar, reservar). La guía de optimización
para IA de Google y el artículo enlazado de web.dev describen tres canales a través
de los cuales los agentes interpretan tu sitio:

1. **Capturas de pantalla + modelo de visión** — interpreta la jerarquía visual, la
   prominencia de los botones, el layout. Lento y costoso en tokens.
2. **HTML/DOM en bruto** — anidamiento, IDs, clases, atributos de datos.
3. **El árbol de accesibilidad** — la destilación semántica nativa del navegador
   (roles, nombres, estados). La señal más limpia de las tres.

Los agentes modernos combinan las tres. Optimizar para el **árbol de accesibilidad**
es la acción de mayor apalancamiento; si tu árbol de accesibilidad está roto, ningún
nivel de pulido visual te salvará.

**Fuentes primarias:**
- Guía de optimización para IA de Google:
  https://developers.google.com/search/docs/fundamentals/ai-optimization-guide
- web.dev (referenciado desde la guía anterior): artículo sobre cómo construir
  sitios web amigables para agentes

## Checklist de Auditoría

### 1. Usa elementos interactivos reales

| Pasa | Falla |
|---|---|
| `<button>` para acciones | `<div onclick="...">` |
| `<a href="...">` para navegación | `<div onclick="window.location...">` |
| `<input>` / `<select>` / `<textarea>` | Widgets `contenteditable` personalizados |

Si no puedes usar una etiqueta interactiva real, aporta ARIA: `role="button"`,
`role="link"`, `tabindex="0"`, más los manejadores de teclas `Enter` y `Space`.

**Por qué importa:** el árbol de accesibilidad expone los elementos interactivos
reales con sus roles. Los widgets div personalizados a menudo aparecen en el árbol
sin ningún rol — los agentes los ignoran.

### 2. Asociaciones de etiquetas

Todo input de formulario debe tener una etiqueta asociada:

```html
<label for="email">Email</label>
<input id="email" type="email" name="email">
```

O usa `aria-label` / `aria-labelledby` donde no sea posible una etiqueta visible.
Los agentes que leen el árbol de accesibilidad obtienen el propósito del campo
directamente de la etiqueta asociada — sin ella, el input es un vacío.

### 3. Tamaño de los objetivos interactivos

Los pipelines de análisis visual filtran los elementos interactivos más pequeños
que **~8 píxeles cuadrados** de área no obstruida. Los mínimos de accesibilidad
de objetivos táctiles (24×24 WCAG AA, 44×44 Apple HIG) son más estrictos y pasan
el filtro de agente por defecto.

Auditoría: cualquier elemento clicable por debajo de 24×24px es candidato a la
invisibilidad para agentes, además del fallo de WCAG.

### 4. No cubras nodos interactivos con overlays transparentes

Los modelos de visión descartan los nodos cubiertos al calcular qué es "interactivo
en esta posición". Infractores comunes:

- Manejadores de clic sobre toda la tarjeta que se superponen a cada enlace hijo.
- Capas transparentes de consentimiento de cookies que persisten más allá del consentimiento.
- Portales modales con `pointer-events: auto` activo tras cerrarse.
- Píxeles de seguimiento "fantasma" con `position: absolute; inset: 0`.

### 5. Estabilidad del layout

Si "Añadir al carrito" se sitúa en posiciones distintas en `/categoria/zapatos`
frente a `/categoria/bolsos`, los agentes basados en capturas de pantalla tienen
que reaprender la página en cada visita. Mantén las acciones funcionalmente
idénticas en el mismo cuadrante de pantalla entre plantillas.

Referencia cruzada: esto se solapa con **CLS** (Cumulative Layout Shift) en Core
Web Vitals, pero la preocupación de agent-UX es más amplia — cubre la estabilidad
de página a página, no solo el desplazamiento dentro de una página.

### 6. `cursor: pointer` como señal legítima

Los modelos de visión leen `cursor: pointer` (definido por defecto en `<a>` /
`<button>`) como una pista de que un elemento es accionable. No lo sobrescribas
a `cursor: default` en elementos verdaderamente interactivos solo por minimalismo visual.

Al revés: no apliques `cursor: pointer` a elementos no interactivos — eso hace
que los agentes hagan clic en cosas que no hacen nada.

### 7. Selectores estables y con significado

Los agentes que recurren al parsing del DOM dependen de:

- Etiquetas semánticas reales (`<nav>`, `<main>`, `<article>`, `<section>`, `<aside>`)
- Atributos `id` estables en los contenedores de layout de nivel superior
- Atributos `data-*` que describen el propósito, no la implementación

Evita nombres de clase autogenerados como `__sc_a4b7d9e2` como único identificador
de un elemento interactivo crítico — los agentes pueden apuntar a ellos pero no
pueden saber qué significan.

## De Cara al Futuro: WebMCP

La guía de optimización para IA de Google menciona **WebMCP**, un estándar propuesto
para la interacción directa sitio-a-agente (análogo al MCP del ecosistema Claude /
Anthropic, pero operando a nivel de página). Existe un programa de preview temprano;
no se espera una adopción amplia antes de 2027.

**Postura de auditoría:** menciona WebMCP en los informes como una señal de cara al
futuro que merece la pena seguir. No marques la ausencia de soporte WebMCP como
hallazgo — el estándar aún no es estable.

## Comprobación Rápida de Un Vistazo

Para una comprobación rápida, captura el árbol de accesibilidad vía Lighthouse o
Chrome DevTools y busca:

- Cualquier elemento interactivo con `role="generic"` → semántica rota.
- Cualquier input sin un `accessible name` → falta la etiqueta.
- Cualquier `<div>` con `onclick` y sin `role` / `tabindex` → widget personalizado
  que los agentes no verán.

`scripts/render_page.py --mode auto` ya carga las páginas en modo headless; ampliarlo
con un volcado del árbol de accesibilidad (`page.accessibility.snapshot()` en Playwright)
es el lugar natural para incorporar una comprobación automatizada de agent-UX en una
futura iteración.

## Última Verificación

18-05-2026. Actualizar cuando:

- WebMCP pase de preview a estable.
- Google publique un framework de puntuación agent-UX independiente.
- web.dev publique un artículo de seguimiento con criterios revisados.
